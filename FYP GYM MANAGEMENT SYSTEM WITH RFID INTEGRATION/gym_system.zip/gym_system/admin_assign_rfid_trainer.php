<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    die("Access denied");
}

$message = "";

// Handle submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $trainer_id = $_POST['trainer_id'] ?? '';
    $tag_uid   = strtoupper(trim($_POST['tag_uid'] ?? ''));

    if ($trainer_id === '' || $tag_uid === '') {
        $message = "Please fill in all fields.";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO rfid_trainer_tags (trainer_id, tag_uid, status)
                VALUES (:tid, :uid, 'Active')
            ");
            $stmt->execute([
                ':tid' => $trainer_id,
                ':uid' => $tag_uid
            ]);
            $message = "Trainer RFID card assigned successfully!";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $message = "This RFID card is already registered.";
            } else {
                $message = "Error: " . $e->getMessage();
            }
        }
    }
}

// Fetch trainers
$trainers = $pdo->query("
    SELECT trainer_id, full_name
    FROM trainers
    ORDER BY full_name
")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Trainer RFID</title>
    <style>
        body { font-family: Arial; background:#f3f4f6; padding:30px; }
        .card { background:#fff; padding:20px; max-width:420px; margin:auto;
                border-radius:10px; box-shadow:0 6px 16px rgba(0,0,0,.1); }
        select,input,button { width:100%; padding:8px; margin-top:8px; }
        button { background:#111827; color:#fff; border:none; font-weight:bold; }
        .msg { margin-top:10px; font-size:13px; color:#2563eb; }
    </style>
</head>
<body>

<div class="card">
    <h2>Assign Trainer RFID Card</h2>

    <form method="POST">
        <label>Trainer</label>
        <select name="trainer_id" required>
            <option value="">-- Select Trainer --</option>
            <?php foreach ($trainers as $t): ?>
                <option value="<?= $t['trainer_id'] ?>">
                    <?= htmlspecialchars($t['full_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>RFID UID</label>
        <input type="text" name="tag_uid" placeholder="Example: C90C4703" required>

        <button type="submit">Assign Trainer Card</button>
    </form>

    <?php if ($message): ?>
        <div class="msg"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
</div>

</body>
</html>
