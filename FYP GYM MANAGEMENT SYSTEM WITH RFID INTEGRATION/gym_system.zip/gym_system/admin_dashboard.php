<?php
session_start();
require_once 'db.php';

// only admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

// Basic stats
$totalMembers  = $pdo->query("SELECT COUNT(*) FROM members")->fetchColumn();
$totalTrainers = $pdo->query("SELECT COUNT(*) FROM trainers")->fetchColumn();
$activeMembers = $pdo->query("SELECT COUNT(*) FROM members WHERE membership_status = 'Active'")->fetchColumn();

// total paid amount
$totalRevenue = $pdo->query("SELECT IFNULL(SUM(amount),0) FROM payments WHERE payment_status = 'Paid'")->fetchColumn();

// today attendance
$today = date('Y-m-d');
$todayAttendance = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE attendance_date = :today");
$todayAttendance->execute([':today' => $today]);
$todayAttendanceCount = $todayAttendance->fetchColumn();

// recent 5 payments
$recentPayments = $pdo->query("
    SELECT p.payment_id, m.full_name AS member_name, p.amount, p.payment_date, p.payment_status
    FROM payments p
    JOIN members m ON p.member_id = m.member_id
    ORDER BY p.payment_date DESC, p.payment_id DESC
    LIMIT 5
")->fetchAll();

// recent 5 new members
$recentMembers = $pdo->query("
    SELECT member_id, full_name, join_date, membership_status
    FROM members
    ORDER BY join_date DESC, member_id DESC
    LIMIT 5
")->fetchAll();

// prevent undefined session warning (display fallback only)
$adminName = $_SESSION['full_name'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin Dashboard</title>

    <style>
        :root{
            --bg:#0b0b0f;
            --panel:#111114;
            --card:rgba(255,255,255,.04);
            --line:rgba(255,255,255,.08);
            --text:#e5e7eb;
            --muted:#9ca3af;
            --accent:#5b5ce6;
            --accent2:#7c8cff;
        }

        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* ===== Topnav (modern) ===== */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;
            border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }

        .navright{
            display:flex;
            align-items:center;
            gap:12px;
        }
        .who{
            font-size: 12px;
            color: var(--muted);
            text-align:right;
            line-height: 1.2;
        }
        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 700;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }

        /* ===== Main container ===== */
        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        /* header panel */
        .hero{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px 18px 14px;
        }
        .hero h1{
            margin:0;
            font-size: 20px;
            letter-spacing:.02em;
        }
        .hero p{
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 13px;
        }

        /* stat cards */
        .grid{
            margin-top:14px;
            display:grid;
            grid-template-columns: repeat(4, minmax(0,1fr));
            gap: 14px;
        }
        .card{
            background: var(--card);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 14px;
            padding: 14px 14px 12px;
        }
        .card h3{
            margin:0 0 8px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .12em;
            color: #cfd3df;
        }
        .value{
            font-size: 24px;
            font-weight: 800;
            margin-bottom:4px;
        }
        .sub{
            color: var(--muted);
            font-size: 12px;
        }

        /* middle layout */
        .layout{
            margin-top: 16px;
            display:grid;
            grid-template-columns: 1.8fr 1.2fr;
            gap: 16px;
        }

        .box{
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }
        .section-title{
            margin:0 0 10px;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: .10em;
            color:#cfd3df;
        }
        .muted{
            color: var(--muted);
            font-size: 13px;
        }

        /* tables */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 12px;
            overflow:hidden;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align:top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{
            background: rgba(255,255,255,.02);
        }

        /* badges */
        .badge-status{
            display:inline-block;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 11px;
            border: 1px solid rgba(255,255,255,.12);
            background: rgba(255,255,255,.06);
        }
        .badge-active{ background: rgba(22,163,74,.18); border-color: rgba(22,163,74,.35); }
        .badge-expired{ background: rgba(185,28,28,.20); border-color: rgba(185,28,28,.35); }
        .badge-pending{ background: rgba(217,119,6,.18); border-color: rgba(217,119,6,.35); }
        .badge-paid{ background: rgba(22,163,74,.18); border-color: rgba(22,163,74,.35); }
        .badge-pending-pay{ background: rgba(217,119,6,.18); border-color: rgba(217,119,6,.35); }
        .badge-overdue{ background: rgba(185,28,28,.20); border-color: rgba(185,28,28,.35); }

        /* quick nav pills */
        .nav-links{
            margin-top: 12px;
        }
        .pill{
            display:inline-block;
            margin: 6px 8px 0 0;
            font-size: 12px;
            padding: 8px 12px;
            border-radius: 999px;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(255,255,255,.10);
            color: #e5e7eb;
            text-decoration:none;
        }
        .pill:hover{
            background: rgba(255,255,255,.09);
            border-color: rgba(124,140,255,.22);
        }

        @media (max-width: 980px){
            .grid{ grid-template-columns: 1fr; }
            .layout{ grid-template-columns: 1fr; }
            .topnav{ padding: 0 14px; }
            .container{ width: calc(100% - 24px); }
            .who{ display:none; }
        }
    </style>
</head>
<body>

<!-- TOPNAV -->
<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Admin</span>
    </div>

    <div class="navright">
        <div class="who">
            <div style="color:#e5e7eb; font-weight:700;">Admin Dashboard</div>
            <div>Welcome, <?php echo htmlspecialchars($adminName); ?></div>
        </div>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">

    <!-- HERO -->
    <div class="hero">
        <h1>Admin Dashboard</h1>
        <p>Monitor members, trainers, revenue, and daily attendance in one place.</p>

        <!-- STATS -->
        <div class="grid">
            <div class="card">
                <h3>Total Members</h3>
                <div class="value"><?php echo (int)$totalMembers; ?></div>
                <div class="sub">Active: <?php echo (int)$activeMembers; ?></div>
            </div>

            <div class="card">
                <h3>Total Trainers</h3>
                <div class="value"><?php echo (int)$totalTrainers; ?></div>
                <div class="sub">Including full-time & part-time</div>
            </div>

            <div class="card">
                <h3>Revenue (Paid Payments)</h3>
                <div class="value">RM <?php echo number_format($totalRevenue, 2); ?></div>
                <div class="sub">All-time collected</div>
            </div>

            <div class="card">
                <h3>Today Attendance</h3>
                <div class="value"><?php echo (int)$todayAttendanceCount; ?></div>
                <div class="sub">For <?php echo htmlspecialchars($today); ?></div>
            </div>
        </div>
    </div>

    <!-- MIDDLE -->
    <div class="layout">

        <!-- Recent Payments -->
        <div class="box">
            <h2 class="section-title">Recent Payments</h2>

            <?php if (count($recentPayments) === 0): ?>
                <p class="muted">No payment records yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Member</th>
                        <th>Amount (RM)</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentPayments as $p): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($p['payment_id']); ?></td>
                            <td><?php echo htmlspecialchars($p['member_name']); ?></td>
                            <td><?php echo number_format($p['amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($p['payment_date']); ?></td>
                            <td>
                                <?php
                                $st = $p['payment_status'];
                                $cls = 'badge-status ';
                                if ($st === 'Paid') $cls .= 'badge-paid';
                                elseif ($st === 'Pending') $cls .= 'badge-pending-pay';
                                else $cls .= 'badge-overdue';
                                ?>
                                <span class="<?php echo $cls; ?>"><?php echo htmlspecialchars($st); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

        <!-- New Members + Quick Nav -->
        <div class="box">
            <h2 class="section-title">New Members</h2>

            <?php if (count($recentMembers) === 0): ?>
                <p class="muted">No members registered yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>Join Date</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($recentMembers as $m): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($m['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($m['join_date']); ?></td>
                            <td>
                                <?php
                                $st = $m['membership_status'];
                                $cls = 'badge-status ';
                                if ($st === 'Active') $cls .= 'badge-active';
                                elseif ($st === 'Expired') $cls .= 'badge-expired';
                                else $cls .= 'badge-pending';
                                ?>
                                <span class="<?php echo $cls; ?>"><?php echo htmlspecialchars($st); ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <div class="nav-links">
                <div class="muted" style="margin-top:12px;">Quick navigation</div>
                <a class="pill" href="admin_members.php">Manage Members</a>
                <a class="pill" href="admin_trainers.php">Manage Trainers</a>
                <a class="pill" href="admin_assign_trainer.php">Assign Trainer</a>
                <a class="pill" href="admin_payments.php">Payment Management</a>
                <a class="pill" href="admin_attendance.php">Attendance Overview</a>
            </div>
        </div>

    </div>

</div>
</body>
</html>
