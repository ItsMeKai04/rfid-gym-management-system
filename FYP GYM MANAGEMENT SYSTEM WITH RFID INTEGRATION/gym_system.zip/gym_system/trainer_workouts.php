<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Trainer') {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM trainers WHERE user_id = :uid LIMIT 1");
$stmt->execute([':uid' => $userId]);
$trainer = $stmt->fetch();

if (!$trainer) {
    die('Trainer profile not found.');
}

$trainerId = $trainer['trainer_id'];
$action    = $_GET['action'] ?? 'list';
$message   = '';
$error     = '';

// ADD
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $difficulty  = $_POST['difficulty'] ?? null;

    if ($title === '') {
        $error = 'Title is required.';
    } else {
        $sql = "INSERT INTO workouts (trainer_id, title, description, difficulty)
                VALUES (:tid, :title, :description, :difficulty)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':tid'         => $trainerId,
            ':title'       => $title,
            ':description' => $description,
            ':difficulty'  => $difficulty,
        ]);
        $message = 'Workout plan created.';
        $action  = 'list';
    }
}

// EDIT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'edit') {
    $workout_id  = (int)($_POST['workout_id'] ?? 0);
    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $difficulty  = $_POST['difficulty'] ?? null;

    if ($workout_id <= 0 || $title === '') {
        $error = 'Workout ID and title are required.';
    } else {
        $sql = "UPDATE workouts
                SET title = :title,
                    description = :description,
                    difficulty = :difficulty
                WHERE workout_id = :wid AND trainer_id = :tid";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':title'       => $title,
            ':description' => $description,
            ':difficulty'  => $difficulty,
            ':wid'         => $workout_id,
            ':tid'         => $trainerId,
        ]);
        if ($stmt->rowCount() > 0) {
            $message = 'Workout updated.';
        } else {
            $error = 'Workout not found or no changes.';
        }
        $action = 'list';
    }
}

// DELETE
if ($action === 'delete' && isset($_GET['id'])) {
    $wid  = (int)$_GET['id'];
    $sql  = "DELETE FROM workouts WHERE workout_id = :wid AND trainer_id = :tid";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':wid' => $wid, ':tid' => $trainerId]);
    if ($stmt->rowCount() > 0) {
        $message = 'Workout deleted.';
    } else {
        $error = 'Workout not found.';
    }
    $action = 'list';
}

// FETCH
$workouts = [];
if ($action === 'list') {
    $sql = "SELECT * FROM workouts WHERE trainer_id = :tid ORDER BY workout_id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':tid' => $trainerId]);
    $workouts = $stmt->fetchAll();
}

$editWorkout = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $wid = (int)$_GET['id'];
    $sql = "SELECT * FROM workouts WHERE workout_id = :wid AND trainer_id = :tid";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':wid' => $wid, ':tid' => $trainerId]);
    $editWorkout = $stmt->fetch();
    if (!$editWorkout) {
        $error  = 'Workout not found.';
        $action = 'list';
    }
}

function diffBadgeClass($d) {
    $d = strtolower(trim((string)$d));
    if ($d === 'beginner') return 'badge badge-beginner';
    if ($d === 'intermediate') return 'badge badge-intermediate';
    if ($d === 'advanced') return 'badge badge-advanced';
    return 'badge badge-none';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Trainer - Workout Plans</title>
    <style>
        :root{
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
            --danger:#b91c1c;
            --success:#16a34a;
            --warn:#d97706;
            --info:#38bdf8;
        }
        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* top sticky nav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.06); }
        .btn-danger{
            background: rgba(185,28,28,.9);
            border-color: rgba(255,255,255,.10);
        }
        .btn-danger:hover{ filter: brightness(1.05); }

        .container{
            width: min(1100px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{ margin:0; font-size: 20px; }
        .small{ margin: 6px 0 0; color: var(--muted); font-size: 13px; }

        /* messages */
        .msg{
            margin-top: 12px;
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            font-size: 13px;
        }
        .msg-success{ border-color: rgba(22,163,74,.25); background: rgba(22,163,74,.10); }
        .msg-error{ border-color: rgba(185,28,28,.25); background: rgba(185,28,28,.10); }

        /* table */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 14px;
            overflow:hidden;
            margin-top: 12px;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{ background: rgba(255,255,255,.02); }

        .actions{ display:flex; gap:8px; flex-wrap:wrap; }

        /* badges */
        .badge{
            display:inline-flex;
            align-items:center;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 900;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
        }
        .badge-beginner{ border-color: rgba(56,189,248,.30); background: rgba(56,189,248,.12); }
        .badge-intermediate{ border-color: rgba(217,119,6,.30); background: rgba(217,119,6,.12); }
        .badge-advanced{ border-color: rgba(185,28,28,.28); background: rgba(185,28,28,.12); }
        .badge-none{ border-color: rgba(107,114,128,.30); background: rgba(107,114,128,.12); }

        /* forms */
        .form-title{ margin: 16px 0 0; font-size: 16px; }
        .form-grid{
            margin-top: 12px;
            display:grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px 14px;
        }
        .form-group{
            display:flex;
            flex-direction:column;
            gap:6px;
        }
        label{ font-size: 12px; color: var(--muted); letter-spacing: .03em; }
        input, select, textarea{
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.25);
            color: var(--text);
        }
        textarea{ min-height: 110px; resize: vertical; }
        input:focus, select:focus, textarea:focus{
            outline:none;
            border-color: rgba(124,140,255,.55);
            box-shadow: 0 0 0 3px rgba(124,140,255,.12);
        }
        .form-actions{
            margin-top: 14px;
            display:flex;
            gap:10px;
            flex-wrap:wrap;
        }
        .hint{
            margin-top:10px;
            color: var(--muted);
            font-size: 12px;
        }

        @media (max-width: 900px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .form-grid{ grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Trainer</span>
    </div>

    <div class="navright">
        <a href="trainer_dashboard.php" class="btn">← Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Workout Plan Management</h1>
                <p class="small">Manage workout plans for your members.</p>
            </div>

            <?php if ($action === 'list'): ?>
                <div>
                    <a href="trainer_workouts.php?action=add" class="btn btn-primary">+ Add Workout Plan</a>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($message): ?>
            <div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($action === 'list'): ?>

            <?php if (count($workouts) === 0): ?>
                <p class="hint">No workout plans yet. Click <b>“Add Workout Plan”</b> to create your first plan.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Difficulty</th>
                        <th style="width:220px;">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($workouts as $w): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($w['workout_id']); ?></td>
                            <td>
                                <div style="font-weight:800;"><?php echo htmlspecialchars($w['title']); ?></div>
                                <?php if (!empty($w['description'])): ?>
                                    <div class="hint" style="margin:6px 0 0;">
                                        <?php echo htmlspecialchars(mb_strimwidth($w['description'], 0, 140, '...')); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="<?php echo diffBadgeClass($w['difficulty']); ?>">
                                    <?php echo htmlspecialchars($w['difficulty'] ?: 'N/A'); ?>
                                </span>
                            </td>
                            <td>
                                <div class="actions">
                                    <a class="btn" href="trainer_workouts.php?action=edit&id=<?php echo $w['workout_id']; ?>">Edit</a>
                                    <a class="btn btn-danger"
                                       href="trainer_workouts.php?action=delete&id=<?php echo $w['workout_id']; ?>"
                                       onclick="return confirm('Delete this workout?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

        <?php elseif ($action === 'add'): ?>

            <h2 class="form-title">Add Workout Plan</h2>
            <p class="hint">Keep it simple and clear (e.g. “Push Day”, “Full Body Beginner”, “Legs + Core”).</p>

            <form method="POST" action="trainer_workouts.php?action=add">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="title">Title *</label>
                        <input type="text" id="title" name="title" required placeholder="e.g. Full Body Beginner">
                    </div>
                    <div class="form-group">
                        <label for="difficulty">Difficulty</label>
                        <select id="difficulty" name="difficulty">
                            <option value="">-- Select --</option>
                            <option value="Beginner">Beginner</option>
                            <option value="Intermediate">Intermediate</option>
                            <option value="Advanced">Advanced</option>
                        </select>
                    </div>

                    <div class="form-group" style="grid-column: span 2;">
                        <label for="description">Description / Exercises</label>
                        <textarea id="description" name="description" placeholder="Example:
1) Bench Press 4x8
2) Incline DB Press 3x10
3) Cable Fly 3x12
Notes: Rest 90s"></textarea>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Save Workout</button>
                    <a href="trainer_workouts.php" class="btn">Cancel</a>
                </div>
            </form>

        <?php elseif ($action === 'edit' && $editWorkout): ?>

            <h2 class="form-title">Edit Workout Plan</h2>
            <p class="hint">Update title, difficulty or exercises anytime.</p>

            <form method="POST" action="trainer_workouts.php?action=edit">
                <input type="hidden" name="workout_id" value="<?php echo htmlspecialchars($editWorkout['workout_id']); ?>">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="title">Title *</label>
                        <input type="text" id="title" name="title" required
                               value="<?php echo htmlspecialchars($editWorkout['title']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="difficulty">Difficulty</label>
                        <select id="difficulty" name="difficulty">
                            <option value="">-- Select --</option>
                            <option value="Beginner" <?php echo $editWorkout['difficulty']==='Beginner'?'selected':''; ?>>Beginner</option>
                            <option value="Intermediate" <?php echo $editWorkout['difficulty']==='Intermediate'?'selected':''; ?>>Intermediate</option>
                            <option value="Advanced" <?php echo $editWorkout['difficulty']==='Advanced'?'selected':''; ?>>Advanced</option>
                        </select>
                    </div>

                    <div class="form-group" style="grid-column: span 2;">
                        <label for="description">Description / Exercises</label>
                        <textarea id="description" name="description"><?php echo htmlspecialchars($editWorkout['description']); ?></textarea>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Workout</button>
                    <a href="trainer_workouts.php" class="btn">Cancel</a>
                </div>
            </form>

        <?php endif; ?>

    </div>
</div>

</body>
</html>
