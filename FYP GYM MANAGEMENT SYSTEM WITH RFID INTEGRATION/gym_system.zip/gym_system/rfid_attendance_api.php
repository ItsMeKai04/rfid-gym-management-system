<?php
require_once 'db.php';
date_default_timezone_set('Asia/Kuala_Lumpur');

header('Content-Type: application/json');

$uid = trim($_GET['uid'] ?? '');
$key = trim($_GET['key'] ?? '');

$API_KEY = "MY_SECRET_KEY"; // sama macam ESP32

if ($key !== $API_KEY) {
    http_response_code(401);
    echo json_encode(["status"=>"error","message"=>"Invalid key"]);
    exit;
}

if ($uid === '') {
    http_response_code(400);
    echo json_encode(["status"=>"error","message"=>"Missing uid"]);
    exit;
}

// 1) Find member by RFID UID
$stmt = $pdo->prepare("
    SELECT rt.member_id
    FROM rfid_tags rt
    WHERE rt.tag_uid = :uid AND rt.status = 'Active'
    LIMIT 1
");
$stmt->execute([':uid' => $uid]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    http_response_code(404);
    echo json_encode(["status"=>"error","message"=>"Card not registered"]);
    exit;
}

$memberId = (int)$row['member_id'];
$today = date('Y-m-d');

// 2) Check if already checked in today (and not checked out)
$stmt = $pdo->prepare("
    SELECT attendance_id, check_in_time, check_out_time
    FROM attendance
    WHERE member_id = :mid AND attendance_date = :d
    ORDER BY attendance_id DESC
    LIMIT 1
");
$stmt->execute([':mid' => $memberId, ':d' => $today]);
$att = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$att) {
    // CHECK-IN
    $stmt = $pdo->prepare("
        INSERT INTO attendance (member_id, check_in_time, attendance_date, status, remarks)
        VALUES (:mid, NOW(), :d, 'Present', 'RFID check-in')
    ");
    $stmt->execute([':mid' => $memberId, ':d' => $today]);

    echo json_encode(["status"=>"ok","action"=>"check_in","member_id"=>$memberId]);
    exit;
}

// If exists but no check_out_time -> CHECK-OUT
if (empty($att['check_out_time'])) {
    $stmt = $pdo->prepare("
        UPDATE attendance
        SET check_out_time = NOW(), remarks = 'RFID check-out'
        WHERE attendance_id = :aid
    ");
    $stmt->execute([':aid' => $att['attendance_id']]);

    echo json_encode(["status"=>"ok","action"=>"check_out","member_id"=>$memberId]);
    exit;
}

// If already checked out, create new check-in (optional behavior)
$stmt = $pdo->prepare("
    INSERT INTO attendance (member_id, check_in_time, attendance_date, status, remarks)
    VALUES (:mid, NOW(), :d, 'Present', 'RFID check-in (2nd)')
");
$stmt->execute([':mid' => $memberId, ':d' => $today]);

echo json_encode(["status"=>"ok","action"=>"check_in_again","member_id"=>$memberId]);
