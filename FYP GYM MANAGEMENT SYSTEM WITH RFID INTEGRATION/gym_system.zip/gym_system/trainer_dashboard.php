<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Trainer') {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Get trainer row
$stmt = $pdo->prepare("SELECT * FROM trainers WHERE user_id = :uid LIMIT 1");
$stmt->execute([':uid' => $userId]);
$trainer = $stmt->fetch();

if (!$trainer) {
    die('Trainer profile not found.');
}

$trainerId   = $trainer['trainer_id'];
$trainerName = $trainer['full_name'];

// Assigned members (from member_trainer_assigned)
$sqlAssigned = "
    SELECT m.member_id, m.full_name
    FROM member_trainer_assigned a
    JOIN members m ON a.member_id = m.member_id
    WHERE a.trainer_id = :tid
    ORDER BY m.full_name
    LIMIT 10
";
$stmt = $pdo->prepare($sqlAssigned);
$stmt->execute([':tid' => $trainerId]);
$assignedMembers = $stmt->fetchAll();

// Upcoming schedules (next 7 days)
$today = date('Y-m-d');
$sqlSchedules = "
    SELECT s.*, m.full_name AS member_name, w.title AS workout_title
    FROM schedules s
    LEFT JOIN members m ON s.member_id = m.member_id
    LEFT JOIN workouts w ON s.workout_id = w.workout_id
    WHERE s.trainer_id = :tid
      AND s.class_date >= :today
    ORDER BY s.class_date, s.start_time
    LIMIT 5
";
$stmt = $pdo->prepare($sqlSchedules);
$stmt->execute([':tid' => $trainerId, ':today' => $today]);
$upcomingSessions = $stmt->fetchAll();

// Recent progress logs
$sqlProgress = "
    SELECT p.*, m.full_name AS member_name
    FROM member_progress p
    JOIN members m ON p.member_id = m.member_id
    WHERE p.trainer_id = :tid
    ORDER BY p.recorded_at DESC
    LIMIT 5
";
$stmt = $pdo->prepare($sqlProgress);
$stmt->execute([':tid' => $trainerId]);
$recentProgress = $stmt->fetchAll();

// Today trainer attendance
$sqlAttend = "
    SELECT * FROM trainer_attendance
    WHERE trainer_id = :tid
      AND attendance_date = :today
    ORDER BY check_in_time DESC
    LIMIT 1
";
$stmt = $pdo->prepare($sqlAttend);
$stmt->execute([':tid' => $trainerId, ':today' => $today]);
$todayAttendance = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Trainer Dashboard</title>
    <style>
        :root{
            --bg:#0b0b0f;
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
            --danger:#b91c1c;
            --success:#16a34a;
            --warn:#d97706;
            --info:#38bdf8;
        }
        *{ box-sizing:border-box; }

        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* Top sticky navbar */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{ display:flex; align-items:center; gap:10px; }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.05); }

        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{ margin:0; font-size: 20px; }
        .small{ margin: 6px 0 0; color: var(--muted); font-size: 13px; }

        /* Stat cards */
        .grid{
            display:grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 14px;
            margin-top: 14px;
        }
        .statcard{
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }
        .statcard h3{
            margin:0 0 6px;
            font-size: 12px;
            letter-spacing:.10em;
            text-transform: uppercase;
            color: #b9c0cf;
        }
        .statval{
            font-size: 26px;
            font-weight: 800;
            margin: 0 0 6px;
        }
        .sub{
            font-size: 12px;
            color: var(--muted);
            line-height: 1.6;
        }

        /* Sections */
        .sections{
            display:grid;
            grid-template-columns: 1.5fr 1fr;
            gap: 14px;
            margin-top: 14px;
        }
        .box{
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }
        .section-title{ margin:0 0 10px; font-size: 16px; }

        /* tables */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 12px;
            overflow:hidden;
            margin-top: 6px;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{ background: rgba(255,255,255,.02); }

        /* assigned members list */
        ul.simple-list{
            list-style:none;
            padding:0;
            margin:0;
        }
        ul.simple-list li{
            padding: 10px 10px;
            border: 1px solid rgba(255,255,255,.06);
            background: rgba(0,0,0,.28);
            border-radius: 12px;
            margin-bottom: 10px;
            display:flex;
            justify-content:space-between;
            align-items:center;
        }
        .pill{
            font-size:11px;
            padding: 4px 10px;
            border-radius: 999px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            color: #d9def0;
        }

        /* badges */
        .badge{
            display:inline-flex;
            align-items:center;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 800;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
        }
        .badge-present{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .badge-none{ border-color: rgba(107,114,128,.35); background: rgba(107,114,128,.12); }

        .tool-links{
            margin-top: 14px;
            display:flex;
            flex-wrap:wrap;
            gap:10px;
        }

        .muted{ color: var(--muted); font-size: 12px; }

        @media (max-width: 1100px){
            .grid{ grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 980px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .sections{ grid-template-columns: 1fr; }
        }
        @media (max-width: 520px){
            .grid{ grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Trainer</span>
    </div>

    <div class="navright">
        <a href="trainer_my_attendance.php" class="btn">My Attendance</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Trainer Dashboard</h1>
                <p class="small">Welcome, <?php echo htmlspecialchars($trainerName); ?> (Trainer)</p>
            </div>
        </div>

        <!-- Stats -->
        <div class="grid">
            <div class="statcard">
                <h3>Assigned Members</h3>
                <div class="statval"><?php echo count($assignedMembers); ?></div>
                <div class="sub">Members assigned to you</div>
            </div>

            <div class="statcard">
                <h3>Upcoming Sessions</h3>
                <div class="statval"><?php echo count($upcomingSessions); ?></div>
                <div class="sub">Next 7 days (from <?php echo htmlspecialchars($today); ?>)</div>
            </div>

            <div class="statcard">
                <h3>Recent Progress Logs</h3>
                <div class="statval"><?php echo count($recentProgress); ?></div>
                <div class="sub">Latest 5 logs</div>
            </div>

            <div class="statcard">
                <h3>Today Attendance</h3>
                <?php if ($todayAttendance): ?>
                    <div class="statval"><span class="badge badge-present">Checked-in</span></div>
                    <div class="sub">
                        In: <?php echo htmlspecialchars($todayAttendance['check_in_time']); ?>
                        <?php if ($todayAttendance['check_out_time']): ?>
                            | Out: <?php echo htmlspecialchars($todayAttendance['check_out_time']); ?>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="statval"><span class="badge badge-none">Not checked-in</span></div>
                    <div class="sub">Use “My Attendance” to check-in</div>
                <?php endif; ?>
            </div>
        </div>

        <div class="sections">
            <!-- Left: Sessions & Progress -->
            <div class="box">
                <h2 class="section-title">Upcoming Sessions</h2>
                <?php if (count($upcomingSessions) === 0): ?>
                    <p class="muted">No upcoming sessions scheduled.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Member</th>
                            <th>Workout</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($upcomingSessions as $s): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($s['class_date']); ?></td>
                                <td><?php echo htmlspecialchars($s['start_time'] . ' - ' . $s['end_time']); ?></td>
                                <td><?php echo htmlspecialchars($s['member_name'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($s['workout_title'] ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

                <h2 class="section-title" style="margin-top:16px;">Recent Member Progress</h2>
                <?php if (count($recentProgress) === 0): ?>
                    <p class="muted">No progress logs yet.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Member</th>
                            <th>Weight (kg)</th>
                            <th>BMI</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($recentProgress as $p): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($p['recorded_at']); ?></td>
                                <td><?php echo htmlspecialchars($p['member_name']); ?></td>
                                <td><?php echo htmlspecialchars($p['weight_kg']); ?></td>
                                <td><?php echo htmlspecialchars($p['bmi']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Right: Assigned Members + Tools -->
            <div class="box">
                <h2 class="section-title">Assigned Members</h2>

                <?php if (count($assignedMembers) === 0): ?>
                    <p class="muted">No members assigned to you yet.</p>
                <?php else: ?>
                    <ul class="simple-list">
                        <?php foreach ($assignedMembers as $m): ?>
                            <li>
                                <span><?php echo htmlspecialchars($m['full_name']); ?></span>
                                <span class="pill">Member</span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <h2 class="section-title" style="margin-top:16px;">Trainer Tools</h2>
                <div class="tool-links">
                    <a href="trainer_workouts.php" class="btn btn-primary">Manage Workout Plans</a>
                    <a href="trainer_schedule.php" class="btn">Manage Schedule</a>
                    <a href="trainer_progress.php" class="btn">Member Progress</a>
                    <a href="trainer_my_attendance.php" class="btn">My Attendance</a>
                </div>

                <p class="muted" style="margin-top:12px;">
                    Tip: Update progress after sessions so members can track their improvement.
                </p>
            </div>
        </div>

    </div>
</div>

</body>
</html>
