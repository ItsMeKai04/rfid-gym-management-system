<?php
session_start();
require_once 'db.php';

// Only admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

$action  = $_GET['action'] ?? 'list';
$message = '';
$error   = '';

$adminName = $_SESSION['full_name'] ?? 'Admin';

// Handle ADD payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
    $member_id      = (int)($_POST['member_id'] ?? 0);
    $amount         = (float)($_POST['amount'] ?? 0);
    $payment_date   = $_POST['payment_date'] ?: null;
    $due_date       = $_POST['due_date'] ?: null;
    $payment_status = $_POST['payment_status'] ?? 'Pending';
    $receipt_number = trim($_POST['receipt_number'] ?? '');

    if ($member_id <= 0 || $amount <= 0) {
        $error = 'Member and valid amount are required.';
    } else {
        try {
            $sql = "INSERT INTO payments 
                        (member_id, amount, payment_date, due_date, payment_status, receipt_number)
                    VALUES 
                        (:member_id, :amount, :payment_date, :due_date, :payment_status, :receipt_number)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':member_id'      => $member_id,
                ':amount'         => $amount,
                ':payment_date'   => $payment_date,
                ':due_date'       => $due_date,
                ':payment_status' => $payment_status,
                ':receipt_number' => $receipt_number,
            ]);
            $message = 'Payment record created successfully.';
            $action  = 'list';
        } catch (PDOException $e) {
            $error = 'Error creating payment: ' . $e->getMessage();
        }
    }
}

// Handle EDIT payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'edit') {
    $payment_id     = (int)($_POST['payment_id'] ?? 0);
    $amount         = (float)($_POST['amount'] ?? 0);
    $payment_date   = $_POST['payment_date'] ?: null;
    $due_date       = $_POST['due_date'] ?: null;
    $payment_status = $_POST['payment_status'] ?? 'Pending';
    $receipt_number = trim($_POST['receipt_number'] ?? '');

    if ($payment_id <= 0 || $amount <= 0) {
        $error = 'Payment ID and valid amount are required.';
    } else {
        try {
            $sql = "UPDATE payments
                    SET amount = :amount,
                        payment_date = :payment_date,
                        due_date = :due_date,
                        payment_status = :payment_status,
                        receipt_number = :receipt_number
                    WHERE payment_id = :payment_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':amount'         => $amount,
                ':payment_date'   => $payment_date,
                ':due_date'       => $due_date,
                ':payment_status' => $payment_status,
                ':receipt_number' => $receipt_number,
                ':payment_id'     => $payment_id,
            ]);
            $message = 'Payment record updated successfully.';
            $action  = 'list';
        } catch (PDOException $e) {
            $error = 'Error updating payment: ' . $e->getMessage();
        }
    }
}

// Handle DELETE
if ($action === 'delete' && isset($_GET['id'])) {
    $payment_id = (int)$_GET['id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM payments WHERE payment_id = :id");
        $stmt->execute([':id' => $payment_id]);
        if ($stmt->rowCount() > 0) {
            $message = 'Payment record deleted successfully.';
        } else {
            $error = 'Payment record not found.';
        }
    } catch (PDOException $e) {
        $error = 'Error deleting payment: ' . $e->getMessage();
    }

    $action = 'list';
}

// Fetch dropdown members
$members = $pdo->query("
    SELECT member_id, full_name
    FROM members
    ORDER BY full_name
")->fetchAll();

// Fetch payments list
$payments = [];
if ($action === 'list') {
    $sql = "
        SELECT p.*, m.full_name AS member_name
        FROM payments p
        JOIN members m ON p.member_id = m.member_id
        ORDER BY p.payment_date DESC, p.payment_id DESC
    ";
    $payments = $pdo->query($sql)->fetchAll();
}

// Fetch single payment for edit
$editPayment = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $payment_id = (int)$_GET['id'];
    $sql = "
        SELECT p.*, m.full_name AS member_name
        FROM payments p
        JOIN members m ON p.member_id = m.member_id
        WHERE p.payment_id = :id
        LIMIT 1
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $payment_id]);
    $editPayment = $stmt->fetch();
    if (!$editPayment) {
        $error  = 'Payment record not found.';
        $action = 'list';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin - Payment Management</title>

    <style>
        :root{
            --bg:#0b0b0f;
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
            --danger:#b91c1c;
            --success:#16a34a;
            --warn:#d97706;
        }

        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* Topnav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;
            border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{ display:flex; align-items:center; gap:10px; }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.05); }
        .btn-danger{
            background: rgba(185,28,28,.85);
            border-color: rgba(185,28,28,.35);
        }
        .btn-danger:hover{ filter: brightness(1.05); }

        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{ margin:0; font-size: 20px; }
        .small{ margin: 6px 0 0; color: var(--muted); font-size: 13px; }

        .msg{
            border-radius: 12px;
            padding: 10px 12px;
            font-size: 13px;
            margin-top: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.05);
        }
        .msg-success{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .msg-error{ border-color: rgba(185,28,28,.35); background: rgba(185,28,28,.12); }

        .box{
            margin-top: 14px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }
        .section-title{ margin:0 0 10px; font-size: 16px; }

        /* Form */
        form{ margin:0; }
        .form-grid{
            display:grid;
            grid-template-columns: repeat(3, minmax(0,1fr));
            gap: 12px 14px;
            align-items:end;
        }
        label{
            font-size: 12px;
            letter-spacing:.04em;
            color: #cfd3df;
        }
        input, select{
            width:100%;
            padding: 10px 10px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.35);
            color: var(--text);
        }
        input:focus, select:focus{
            outline:none;
            border-color: rgba(124,140,255,.7);
            box-shadow: 0 0 0 3px rgba(124,140,255,.15);
        }
        .form-actions{
            margin-top: 12px;
            display:flex;
            gap:10px;
            flexs;
        }

        /* Table */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 12px;
            overflow:hidden;
            margin-top: 8px;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{ background: rgba(255,255,255,.02); }

        .badge{
            display:inline-flex;
            align-items:center;
            gap:6px;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
        }
        .badge-paid{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .badge-pending{ border-color: rgba(217,119,6,.35); background: rgba(217,119,6,.12); }
        .badge-overdue{ border-color: rgba(185,28,28,.35); background: rgba(185,28,28,.12); }

        .muted{ color: var(--muted); font-size: 12px; }

        @media (max-width: 980px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .form-grid{ grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Payments</span>
    </div>
    <div class="navright">
        <a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Payment Management</h1>
                <p class="small">Logged in as: <?php echo htmlspecialchars($adminName); ?> (Admin)</p>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($action === 'list'): ?>

            <div class="box">
                <h2 class="section-title">Add New Payment</h2>
                <form method="POST" action="admin_payments.php?action=add">
                    <div class="form-grid">
                        <div>
                            <label for="member_id">Member *</label><br>
                            <select name="member_id" id="member_id" required>
                                <option value="">-- Select Member --</option>
                                <?php foreach ($members as $m): ?>
                                    <option value="<?php echo $m['member_id']; ?>">
                                        <?php echo htmlspecialchars($m['full_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label for="amount">Amount (RM) *</label><br>
                            <input type="number" step="0.01" min="0" name="amount" id="amount" required>
                        </div>

                        <div>
                            <label for="payment_date">Payment Date</label><br>
                            <input type="date" name="payment_date" id="payment_date">
                        </div>

                        <div>
                            <label for="due_date">Due Date</label><br>
                            <input type="date" name="due_date" id="due_date">
                        </div>

                        <div>
                            <label for="payment_status">Status</label><br>
                            <select name="payment_status" id="payment_status">
                                <option value="Pending">Pending</option>
                                <option value="Paid">Paid</option>
                                <option value="Overdue">Overdue</option>
                            </select>
                        </div>

                        <div>
                            <label for="receipt_number">Receipt No.</label><br>
                            <input type="text" name="receipt_number" id="receipt_number" placeholder="Optional">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Save Payment</button>
                    </div>
                </form>
            </div>

            <div class="box">
                <h2 class="section-title">All Payments</h2>

                <?php if (count($payments) === 0): ?>
                    <p class="muted">No payment records yet.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Member</th>
                            <th>Amount (RM)</th>
                            <th>Payment Date</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Receipt</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($payments as $p): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($p['payment_id']); ?></td>
                                <td><?php echo htmlspecialchars($p['member_name']); ?></td>
                                <td><?php echo number_format($p['amount'], 2); ?></td>
                                <td><?php echo htmlspecialchars($p['payment_date']); ?></td>
                                <td><?php echo htmlspecialchars($p['due_date']); ?></td>
                                <td>
                                    <?php
                                    $st  = $p['payment_status'];
                                    $cls = 'badge ';
                                    if ($st === 'Paid') $cls .= 'badge-paid';
                                    elseif ($st === 'Pending') $cls .= 'badge-pending';
                                    else $cls .= 'badge-overdue';
                                    ?>
                                    <span class="<?php echo $cls; ?>"><?php echo htmlspecialchars($st); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($p['receipt_number']); ?></td>
                                <td style="display:flex; gap:8px; flex-wrap:wrap;">
                                    <a class="btn" href="admin_payments.php?action=edit&id=<?php echo $p['payment_id']; ?>">Edit</a>
                                    <a class="btn btn-danger"
                                       href="admin_payments.php?action=delete&id=<?php echo $p['payment_id']; ?>"
                                       onclick="return confirm('Delete this payment record?');">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

        <?php elseif ($action === 'edit' && $editPayment): ?>

            <div class="box">
                <h2 class="section-title">Edit Payment</h2>
                <p class="small">Member: <strong><?php echo htmlspecialchars($editPayment['member_name']); ?></strong></p>

                <form method="POST" action="admin_payments.php?action=edit">
                    <input type="hidden" name="payment_id" value="<?php echo htmlspecialchars($editPayment['payment_id']); ?>">

                    <div class="form-grid">
                        <div>
                            <label for="amount">Amount (RM) *</label><br>
                            <input type="number" step="0.01" min="0" name="amount" id="amount" required
                                   value="<?php echo htmlspecialchars($editPayment['amount']); ?>">
                        </div>

                        <div>
                            <label for="payment_date">Payment Date</label><br>
                            <input type="date" name="payment_date" id="payment_date"
                                   value="<?php echo htmlspecialchars($editPayment['payment_date']); ?>">
                        </div>

                        <div>
                            <label for="due_date">Due Date</label><br>
                            <input type="date" name="due_date" id="due_date"
                                   value="<?php echo htmlspecialchars($editPayment['due_date']); ?>">
                        </div>

                        <div>
                            <label for="payment_status">Status</label><br>
                            <select name="payment_status" id="payment_status">
                                <option value="Pending" <?php echo $editPayment['payment_status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                <option value="Paid" <?php echo $editPayment['payment_status'] === 'Paid' ? 'selected' : ''; ?>>Paid</option>
                                <option value="Overdue" <?php echo $editPayment['payment_status'] === 'Overdue' ? 'selected' : ''; ?>>Overdue</option>
                            </select>
                        </div>

                        <div>
                            <label for="receipt_number">Receipt No.</label><br>
                            <input type="text" name="receipt_number" id="receipt_number"
                                   value="<?php echo htmlspecialchars($editPayment['receipt_number']); ?>">
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Update Payment</button>
                        <a href="admin_payments.php" class="btn">Cancel</a>
                    </div>
                </form>
            </div>

        <?php endif; ?>

    </div>
</div>

</body>
</html>
