<?php
session_start();
require_once 'db.php';

// SECURITY (optional – adjust ikut sistem login kau)
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    die("Access denied");
}

$message = "";

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $member_id = $_POST['member_id'] ?? '';
    $tag_uid   = strtoupper(trim($_POST['tag_uid'] ?? ''));

    if ($member_id === '' || $tag_uid === '') {
        $message = "Please fill in all fields.";
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO rfid_tags (member_id, tag_uid, status)
                VALUES (:mid, :uid, 'Active')
            ");
            $stmt->execute([
                ':mid' => $member_id,
                ':uid' => $tag_uid
            ]);

            $message = "RFID card successfully assigned!";
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $message = "This RFID card is already registered.";
            } else {
                $message = "Error: " . $e->getMessage();
            }
        }
    }
}

// Fetch members
$members = $pdo->query("
    SELECT member_id, full_name 
    FROM members 
    ORDER BY full_name
")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign RFID Card</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f4f6;
            padding: 30px;
        }
        .card {
            background: #fff;
            padding: 20px;
            max-width: 420px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 6px 16px rgba(0,0,0,.1);
        }
        h2 { margin-top: 0; }
        label { display: block; margin-top: 12px; }
        select, input {
            width: 100%;
            padding: 8px;
            margin-top: 4px;
        }
        button {
            margin-top: 16px;
            padding: 10px;
            width: 100%;
            border: none;
            background: #111827;
            color: #fff;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
        }
        .msg {
            margin-top: 12px;
            font-size: 13px;
            color: #2563eb;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Assign RFID Card</h2>

    <form method="POST">
        <label>Member</label>
        <select name="member_id" required>
            <option value="">-- Select Member --</option>
            <?php foreach ($members as $m): ?>
                <option value="<?= $m['member_id'] ?>">
                    <?= htmlspecialchars($m['full_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>RFID UID</label>
        <input type="text" name="tag_uid" placeholder="Example: C90C4703" required>

        <button type="submit">Assign Card</button>
    </form>

    <?php if ($message): ?>
        <div class="msg"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
</div>

</body>
</html>
