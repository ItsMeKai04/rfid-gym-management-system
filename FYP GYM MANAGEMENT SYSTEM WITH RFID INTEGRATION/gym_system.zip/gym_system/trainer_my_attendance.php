<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Trainer') {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$stmt   = $pdo->prepare("SELECT * FROM trainers WHERE user_id = :uid LIMIT 1");
$stmt->execute([':uid'=>$userId]);
$trainer = $stmt->fetch();
if (!$trainer) die('Trainer not found.');
$trainerId = $trainer['trainer_id'];

$message = '';
$error   = '';

$today = date('Y-m-d');

// check if already have record today
$stmt = $pdo->prepare("
    SELECT * FROM trainer_attendance
    WHERE trainer_id = :tid AND attendance_date = :today
    ORDER BY check_in_time ASC
    LIMIT 1
");
$stmt->execute([':tid'=>$trainerId, ':today'=>$today]);
$todayRecord = $stmt->fetch();

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['attendance_action'] ?? '';

    if ($action === 'check_in') {
        if ($todayRecord) {
            $error = 'You already checked in today.';
        } else {
            $sql = "
                INSERT INTO trainer_attendance (trainer_id, check_in_time, attendance_date, status, remarks)
                VALUES (:tid, NOW(), :today, 'Present', 'Auto check-in')
            ";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':tid'=>$trainerId, ':today'=>$today]);
            $message = 'Check-in successful.';
        }
    } elseif ($action === 'check_out') {
        if (!$todayRecord) {
            $error = 'You have not checked in yet.';
        } elseif ($todayRecord['check_out_time']) {
            $error = 'You already checked out today.';
        } else {
            $sql = "
                UPDATE trainer_attendance
                SET check_out_time = NOW()
                WHERE trainer_attendance_id = :id
            ";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':id'=>$todayRecord['trainer_attendance_id']]);
            $message = 'Check-out successful.';
        }
    }

    // refresh record
    $stmt = $pdo->prepare("
        SELECT * FROM trainer_attendance
        WHERE trainer_id = :tid AND attendance_date = :today
        ORDER BY check_in_time ASC
        LIMIT 1
    ");
    $stmt->execute([':tid'=>$trainerId, ':today'=>$today]);
    $todayRecord = $stmt->fetch();
}

// Last 10 attendance
$sql = "
    SELECT * FROM trainer_attendance
    WHERE trainer_id = :tid
    ORDER BY attendance_date DESC, check_in_time DESC
    LIMIT 10
";
$stmt = $pdo->prepare($sql);
$stmt->execute([':tid'=>$trainerId]);
$history = $stmt->fetchAll();

function h($v){ return htmlspecialchars((string)$v ?? ''); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Trainer - My Attendance</title>
    <style>
        :root{
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
        }
        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* top sticky nav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.06); }

        .container{
            width: min(900px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{ margin:0; font-size: 20px; }
        .small{ margin: 6px 0 0; color: var(--muted); font-size: 13px; }

        .msg{
            margin-top: 12px;
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            font-size: 13px;
        }
        .msg-success{ border-color: rgba(22,163,74,.25); background: rgba(22,163,74,.10); }
        .msg-error{ border-color: rgba(185,28,28,.25); background: rgba(185,28,28,.10); }

        .section-title{ margin: 16px 0 8px; font-size: 16px; }

        /* Today strip */
        .today-strip{
            margin-top: 12px;
            padding: 12px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,.08);
            background: rgba(255,255,255,.03);
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap: 12px;
            flex-wrap:wrap;
        }
        .today-strip .meta{
            font-size: 13px;
            color: var(--muted);
        }
        .today-strip strong{ color: var(--text); }

        .badge{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 800;
            border: 1px solid rgba(255,255,255,.12);
            background: rgba(255,255,255,.04);
        }
        .badge-ok{ border-color: rgba(22,163,74,.25); background: rgba(22,163,74,.10); }
        .badge-wait{ border-color: rgba(245,158,11,.25); background: rgba(245,158,11,.10); }

        /* table */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 14px;
            overflow:hidden;
            margin-top: 10px;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{ background: rgba(255,255,255,.02); }

        @media (max-width: 900px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Trainer</span>
    </div>

    <div class="navright">
        <a href="trainer_dashboard.php" class="btn">← Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>My Attendance</h1>
                <p class="small">Check-in and check-out for accountability.</p>
            </div>
        </div>

        <?php if ($message): ?><div class="msg msg-success"><?php echo h($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="msg msg-error"><?php echo h($error); ?></div><?php endif; ?>

        <div class="today-strip">
            <div class="meta">
                Today: <strong><?php echo h($today); ?></strong>
                <?php if ($todayRecord): ?>
                    <span style="margin-left:10px;">
                        Check-in: <strong><?php echo h($todayRecord['check_in_time']); ?></strong>
                        <?php if ($todayRecord['check_out_time']): ?>
                            • Check-out: <strong><?php echo h($todayRecord['check_out_time']); ?></strong>
                        <?php endif; ?>
                    </span>
                <?php endif; ?>
            </div>

            <form method="POST" style="margin:0;">
                <?php if (!$todayRecord): ?>
                    <button type="submit" name="attendance_action" value="check_in" class="btn btn-primary">Check In</button>
                <?php else: ?>
                    <?php if (!$todayRecord['check_out_time']): ?>
                        <span class="badge badge-wait">Status: Checked-in</span>
                        <button type="submit" name="attendance_action" value="check_out" class="btn btn-primary">Check Out</button>
                    <?php else: ?>
                        <span class="badge badge-ok">Status: Completed</span>
                    <?php endif; ?>
                <?php endif; ?>
            </form>
        </div>

        <h2 class="section-title">Recent Attendance</h2>

        <?php if (count($history) === 0): ?>
            <p class="small">No attendance records yet.</p>
        <?php else: ?>
            <table>
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Check-in</th>
                    <th>Check-out</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($history as $hrow): ?>
                    <tr>
                        <td><?php echo h($hrow['attendance_date']); ?></td>
                        <td><?php echo h($hrow['check_in_time']); ?></td>
                        <td><?php echo h($hrow['check_out_time']); ?></td>
                        <td><?php echo h($hrow['status']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

    </div>
</div>

</body>
</html>
