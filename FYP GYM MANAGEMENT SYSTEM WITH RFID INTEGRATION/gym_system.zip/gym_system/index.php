<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to GymBroz</title>
  <style>
    body {
      margin: 0;
      font-family: 'Arial', sans-serif;
      background: #101010;
      color: #fff;
      overflow-x: hidden;
    }

    /* Sticky Top Navigation Bar */
    .topnav {
      position: fixed;
      top: 0;
      width: 100%;
      background: rgba(0, 0, 0, 0.7);
      padding: 70px 80px;  /* Increased padding for thicker nav */
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 100;
      box-sizing: border-box;
    }

    /* Center the logo and navigation links */
    .topnav .logo {
      font-size: 22px;
      font-weight: 700;
      color: #5b67f0;
      flex-grow: 1; /* Allow the logo to use available space */
    }

    .topnav .nav-links {
      display: flex;
      gap: 26px;
      font-size: 14px;
      letter-spacing: 0.05em;
      justify-content: center; /* Center the links */
      flex-grow: 3; /* Adjust the link container size */
    }

    .topnav a {
      color: white;
      text-decoration: none;
      font-size: 18px;
      font-weight: 600;
      text-transform: uppercase;
    }

    .topnav a:hover {
      color: #5b67f0;
    }

    .topnav .logout-link {
      font-size: 13px;
      color: #f9fafb;
      text-decoration: none;
      padding: 6px 12px;
      border-radius: 999px;
      border: 1px solid rgba(249,250,251,0.4);
    }

    .topnav .logout-link:hover {
      background: #4b5563;
    }

    /* Main Container */
    .container {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
      padding-top: 100px; /* Offset for sticky topnav */
    }

    /* Hero Section */
    .hero {
      width: 100%;
      height: 100vh;
      background: url('https://www.primalstrength.com/cdn/shop/files/gymdesign_render_Two_collumn_grid_cb1b5850-fa8e-4a7b-a2b3-190c2e45facd.jpg?v=1680719688&width=1500') no-repeat center center/cover;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: center;
      position: relative;
      color: white;
    }

    .hero::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.5);
    }

    .hero-content {
      position: relative;
      z-index: 1;
    }

    .hero h1 {
      font-size: 4rem;
      margin: 0;
      font-weight: bold;
      text-shadow: 2px 2px 8px rgba(0,0,0,0.7);
    }

    .hero p {
      font-size: 1.2rem;
      margin-top: 20px;
      font-weight: 300;
      line-height: 1.5;
      text-shadow: 1px 1px 5px rgba(0,0,0,0.7);
    }

    .btn {
      padding: 14px 36px;
      background-color: #5b67f0;
      border: none;
      border-radius: 25px;
      color: white;
      text-decoration: none;
      font-size: 18px;
      font-weight: bold;
      cursor: pointer;
      margin-top: 25px;
      transition: 0.3s;
    }

    .btn:hover {
      background-color: #4a53e0;
      transform: scale(1.05);
    }

    /* About Section */
    .about-section {
      background: #18181b;
      color: #d1d5db;
      padding: 50px 20px;
      text-align: center;
    }

    .about-section h2 {
      font-size: 2.5rem;
      margin-bottom: 20px;
    }

    .about-section p {
      font-size: 1.2rem;
      line-height: 1.6;
    }

    /* Features Section */
    .features {
      display: flex;
      justify-content: space-around;
      gap: 30px;
      margin-top: 50px;
      flex-wrap: wrap;
    }

    .feature-card {
      background: #1f2937;
      padding: 30px;
      border-radius: 15px;
      width: 250px;
      text-align: center;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    }

    .feature-card h3 {
      font-size: 1.7rem;
      color: #ffffff;
      margin-bottom: 15px;
    }

    .feature-card p {
      font-size: 1.1rem;
      color: #9ca3af;
      line-height: 1.5;
    }

    /* Footer Section */
    .footer {
      background-color: #111827;
      color: #d1d5db;
      padding: 30px 20px;
      text-align: center;
      margin-top: 100px;
    }

    .footer a {
      color: #aab3ff;
      text-decoration: none;
      font-weight: 600;
    }

    /* Mobile Adjustments */
    @media (max-width: 768px) {
      .hero h1 {
        font-size: 2.5rem;
      }

      .hero p {
        font-size: 1rem;
      }

      .features {
        flex-direction: column;
        align-items: center;
      }

      .feature-card {
        width: 90%;
        margin: 20px 0;
      }
    }
  </style>
</head>
<body>

<!-- Top Navigation Bar -->
<div class="topnav">
  <div class="logo">GymBroz</div>
  <div class="nav-links">
    <a href="index.php">Home</a>
    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
    <a href="contact.php">Contact Us</a>
  </div>
</div>

<!-- Main Container -->
<div class="container">

  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-content">
      <h1>Welcome to GymBroz</h1>
      <p>Your fitness journey begins here. Join our community and start your transformation today!</p>
      <a href="login.php" class="btn">Login / Register</a>
    </div>
  </section>

  <!-- About Section -->
  <section class="about-section">
    <h2>About Us</h2>
    <p>At our gym, we offer personalized fitness plans, cardio, strength training, yoga, and much more. With our state-of-the-art equipment and experienced trainers, we help you achieve your fitness goals, whatever they may be.</p>
  </section>

  <!-- Features Section -->
  <section class="features">
    <div class="feature-card">
      <h3>Cardio Classes</h3>
      <p>Get your heart pumping with our exciting cardio classes designed to burn fat and improve endurance.</p>
    </div>
    <div class="feature-card">
      <h3>Strength Training</h3>
      <p>Build muscle, tone your body, and enhance your strength with our professional weight training programs.</p>
    </div>
    <div class="feature-card">
      <h3>Personal Training</h3>
      <p>Work one-on-one with certified personal trainers to achieve your goals faster and more effectively.</p>
    </div>
  </section>

  <!-- Footer Section -->
  <footer class="footer">
    <p>&copy; 2025 GymBroz. All Rights Reserved.</p>
    <p><a href="contact.php">Contact Us</a></p>
  </footer>

</div>

</body>
</html>
