<?php
require_once 'db.php';
date_default_timezone_set('Asia/Kuala_Lumpur');
header('Content-Type: application/json');

$API_KEY = "MY_SECRET_KEY";

$uid = strtoupper(trim($_GET['uid'] ?? ''));
$key = trim($_GET['key'] ?? '');

if ($key !== $API_KEY) {
    http_response_code(401);
    echo json_encode(["status"=>"error","message"=>"Invalid API key"]);
    exit;
}
if ($uid === '') {
    http_response_code(400);
    echo json_encode(["status"=>"error","message"=>"UID missing"]);
    exit;
}

$today = date('Y-m-d');

/* =========================================================
   1) CHECK IF UID IS MEMBER CARD
   ========================================================= */
$stmt = $pdo->prepare("
    SELECT member_id
    FROM rfid_tags
    WHERE tag_uid = :uid AND status = 'Active'
    LIMIT 1
");
$stmt->execute([':uid' => $uid]);
$member = $stmt->fetch(PDO::FETCH_ASSOC);

if ($member) {
    $memberId = (int)$member['member_id'];

    // Find latest attendance today
    $stmt = $pdo->prepare("
        SELECT attendance_id, check_in_time, check_out_time
        FROM attendance
        WHERE member_id = :mid AND attendance_date = :d
        ORDER BY attendance_id DESC
        LIMIT 1
    ");
    $stmt->execute([':mid'=>$memberId, ':d'=>$today]);
    $att = $stmt->fetch(PDO::FETCH_ASSOC);

    // No record today -> check-in
    if (!$att) {
        $stmt = $pdo->prepare("
            INSERT INTO attendance (member_id, check_in_time, attendance_date, status, remarks)
            VALUES (:mid, NOW(), :d, 'Present', 'RFID member check-in')
        ");
        $stmt->execute([':mid'=>$memberId, ':d'=>$today]);

        echo json_encode(["status"=>"ok","role"=>"Member","action"=>"check_in","member_id"=>$memberId]);
        exit;
    }

    // Has check-in but no check-out -> check-out
    if (empty($att['check_out_time'])) {
        $stmt = $pdo->prepare("
            UPDATE attendance
            SET check_out_time = NOW(), remarks = 'RFID member check-out'
            WHERE attendance_id = :aid
        ");
        $stmt->execute([':aid'=>$att['attendance_id']]);

        echo json_encode(["status"=>"ok","role"=>"Member","action"=>"check_out","member_id"=>$memberId]);
        exit;
    }

    // Already checked out -> optional new check-in
    $stmt = $pdo->prepare("
        INSERT INTO attendance (member_id, check_in_time, attendance_date, status, remarks)
        VALUES (:mid, NOW(), :d, 'Present', 'RFID member re-check-in')
    ");
    $stmt->execute([':mid'=>$memberId, ':d'=>$today]);

    echo json_encode(["status"=>"ok","role"=>"Member","action"=>"check_in_again","member_id"=>$memberId]);
    exit;
}

/* =========================================================
   2) CHECK IF UID IS TRAINER CARD
   ========================================================= */
$stmt = $pdo->prepare("
    SELECT trainer_id
    FROM rfid_trainer_tags
    WHERE tag_uid = :uid AND status = 'Active'
    LIMIT 1
");
$stmt->execute([':uid' => $uid]);
$trainer = $stmt->fetch(PDO::FETCH_ASSOC);

if ($trainer) {
    $trainerId = (int)$trainer['trainer_id'];
    $today = date('Y-m-d');

    // Check latest trainer attendance today
    $stmt = $pdo->prepare("
        SELECT trainer_attendance_id, check_in_time, check_out_time
        FROM trainer_attendance
        WHERE trainer_id = :tid AND attendance_date = :d
        ORDER BY trainer_attendance_id DESC
        LIMIT 1
    ");
    $stmt->execute([
        ':tid' => $trainerId,
        ':d'   => $today
    ]);
    $att = $stmt->fetch(PDO::FETCH_ASSOC);

    // No record today → CHECK-IN
    if (!$att) {
        $stmt = $pdo->prepare("
            INSERT INTO trainer_attendance
            (trainer_id, check_in_time, attendance_date, status, remarks)
            VALUES (:tid, NOW(), :d, 'Present', 'RFID trainer check-in')
        ");
        $stmt->execute([
            ':tid' => $trainerId,
            ':d'   => $today
        ]);

        echo json_encode([
            "status" => "ok",
            "role"   => "Trainer",
            "action" => "check_in",
            "trainer_id" => $trainerId
        ]);
        exit;
    }

    // Has check-in but no check-out → CHECK-OUT
    if (empty($att['check_out_time'])) {
        $stmt = $pdo->prepare("
            UPDATE trainer_attendance
            SET check_out_time = NOW(),
                remarks = 'RFID trainer check-out'
            WHERE trainer_attendance_id = :id
        ");
        $stmt->execute([
            ':id' => $att['trainer_attendance_id']
        ]);

        echo json_encode([
            "status" => "ok",
            "role"   => "Trainer",
            "action" => "check_out",
            "trainer_id" => $trainerId
        ]);
        exit;
    }

    // Already checked out → optional re-check-in
    $stmt = $pdo->prepare("
        INSERT INTO trainer_attendance
        (trainer_id, check_in_time, attendance_date, status, remarks)
        VALUES (:tid, NOW(), :d, 'Present', 'RFID trainer re-check-in')
    ");
    $stmt->execute([
        ':tid' => $trainerId,
        ':d'   => $today
    ]);

    echo json_encode([
        "status" => "ok",
        "role"   => "Trainer",
        "action" => "check_in_again",
        "trainer_id" => $trainerId
    ]);
    exit;
}


/* =========================================================
   3) NOT REGISTERED
   ========================================================= */
http_response_code(404);
echo json_encode([
    "status" => "error",
    "message" => "Card not registered (not member or trainer)"
]);
