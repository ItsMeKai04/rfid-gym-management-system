<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us - GymBroz</title>
  <style>
    /* General Body Styles */
    body {
      margin: 0;
      font-family: 'Arial', sans-serif;
      background: #101010;
      color: #fff;
    }

    /* Top Navigation Bar for Contact Us Page */
    .topnav {
      position: fixed;
      top: 0;
      width: 100%;
      background: rgba(0, 0, 0, 0.7);
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 100;
      box-sizing: border-box;
    }

    .topnav a {
      color: white;
      text-decoration: none;
      font-size: 18px;
      font-weight: 600;
      margin-right: 30px;
      text-transform: uppercase;
    }

    .topnav a:hover {
      color: #5b67f0;
    }

    .topnav .logo {
      font-size: 22px;
      font-weight: 700;
      color: #5b67f0;
    }

    .topnav .nav-links {
      display: flex;
      gap: 26px;
      font-size: 14px;
      letter-spacing: 0.05em;
      justify-content: center;
      flex-grow: 1;
    }

    .topnav .nav-links a {
      color: #f9fafb;
      text-decoration: none;
      font-weight: 600;
    }

    .topnav .nav-links a:hover {
      color: #5b67f0;
    }

    .topnav .logout-link {
      font-size: 13px;
      color: #f9fafb;
      text-decoration: none;
      padding: 6px 12px;
      border-radius: 999px;
      border: 1px solid rgba(249,250,251,0.4);
    }

    .topnav .logout-link:hover {
      background: #4b5563;
    }

    /* Main Container */
    .container {
      padding-top: 100px;
      width: 100%;
      padding: 40px;
      text-align: center;
      color: #fff;
    }

    /* Section Title */
    h2 {
      font-size: 2.5rem;
      color: #ffffff;
      margin-bottom: 20px;
    }

    /* Contact Information */
    .contact-info {
      margin: 40px 0;
      font-size: 1.2rem;
      color: #d1d5db;
      line-height: 1.8;
    }

    /* Contact Form */
    .contact-form {
      background: #18181b;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
      width: 80%;
      max-width: 600px;
      margin: auto;
    }

    .contact-form input,
    .contact-form textarea {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border: 1px solid #d4d4d8;
      border-radius: 8px;
      background: #ffffff;
      color: #111827;
    }

    .contact-form button {
      padding: 14px 36px;
      background-color: #5b67f0;
      border: none;
      border-radius: 25px;
      color: white;
      font-size: 18px;
      font-weight: bold;
      cursor: pointer;
      transition: 0.3s;
    }

    .contact-form button:hover {
      background-color: #4a53e0;
      transform: scale(1.05);
    }

    /* Map Section */
    .map {
      margin-top: 40px;
      width: 100%;
      height: 400px;
      background: #ddd;
    }

    /* Footer Section */
    .footer {
      background-color: #111827;
      color: #d1d5db;
      padding: 30px 20px;
      text-align: center;
      margin-top: 50px;
    }

    .footer a {
      color: #aab3ff;
      text-decoration: none;
      font-weight: 600;
    }

    /* Mobile Adjustments */
    @media (max-width: 768px) {
      .hero h1 {
        font-size: 2.5rem;
      }

      .hero p {
        font-size: 1rem;
      }

      .features {
        flex-direction: column;
        align-items: center;
      }

      .feature-card {
        width: 90%;
        margin: 20px 0;
      }
    }
  </style>
</head>
<body>

<!-- Top Navigation Bar -->
<div class="topnav">
  <div class="logo">GymBroz</div>
  <div class="nav-links">
    <a href="index.php">Home</a>
    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
    <a href="contact.php">Contact Us</a>
  </div>
</div>

<!-- Main Container -->
<div class="container">

  <!-- Section Title -->
  <h2>Contact Us</h2>

  <!-- Contact Information -->
  <div class="contact-info">
    <p>Feel free to reach out to us with any questions or feedback. We're here to help you achieve your fitness goals!</p>
    <p><strong>Phone:</strong> +123-456-7890</p>
    <p><strong>Email:</strong> support@gymsystem.com</p>
    <p><strong>Address:</strong> 123 Gym Avenue, Fitness City, 12345</p>
  </div>

  <!-- Contact Form -->
  <form action="submit_contact_form.php" method="POST" class="contact-form">
    <h3>Send us a Message</h3>
    <input type="text" name="name" placeholder="Your Name" required>
    <input type="email" name="email" placeholder="Your Email" required>
    <textarea name="message" placeholder="Your Message" rows="5" required></textarea>
    <button type="submit">Send Message</button>
  </form>

  <!-- Map Section (Embed Google Maps) -->
  <div class="map">
    <!-- Replace with your actual map -->
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3162.273536216681!2d127.0714012!3d37.5665321!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x357c21326a8fc23f%3A0x23423f23423f232!2sGym%20Location%20Name!5e0!3m2!1sen!2sus!4v1627892303132!5m2!1sen!2sus" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
  </div>

</div>

<!-- Footer Section -->
<footer class="footer">
  <p>&copy; 2025 GymBroz. All Rights Reserved.</p>
  <p><a href="contact.php">Contact Us</a></p>
</footer>

</body>
</html>
