<?php
session_start();
require_once 'db.php';

// Only admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

$action  = $_GET['action'] ?? 'list';
$message = '';
$error   = '';

$adminName = $_SESSION['full_name'] ?? 'Admin';

// Helper: get trainer data (join users + trainers)
function getTrainerById(PDO $pdo, $trainer_id) {
    $sql = "SELECT t.*, u.username, u.email AS user_email, u.full_name AS user_full_name, u.user_id
            FROM trainers t
            JOIN users u ON t.user_id = u.user_id
            WHERE t.trainer_id = :trainer_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':trainer_id' => $trainer_id]);
    return $stmt->fetch();
}

/**
 * HANDLE FORM SUBMISSIONS
 */

// ADD TRAINER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
    $username       = trim($_POST['username'] ?? '');
    $password       = $_POST['password'] ?? '';
    $full_name      = trim($_POST['full_name'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $phone_number   = trim($_POST['phone_number'] ?? '');
    $specialization = trim($_POST['specialization'] ?? '');
    $availability   = trim($_POST['availability_schedule'] ?? '');

    if ($username === '' || $password === '' || $full_name === '') {
        $error = 'Username, password and full name are required.';
    } else {
        try {
            $pdo->beginTransaction();

            // 1) Insert into users (role = Trainer)
            $sqlUser = "INSERT INTO users (username, password_hash, full_name, email, role, status)
                        VALUES (:username, SHA2(:password, 256), :full_name, :email, 'Trainer', 'Active')";
            $stmtUser = $pdo->prepare($sqlUser);
            $stmtUser->execute([
                ':username'  => $username,
                ':password'  => $password,
                ':full_name' => $full_name,
                ':email'     => $email,
            ]);
            $user_id = $pdo->lastInsertId();

            // 2) Insert into trainers
            $sqlTrainer = "INSERT INTO trainers
                (user_id, full_name, specialization, email, phone_number, availability_schedule)
                VALUES
                (:user_id, :full_name, :specialization, :email, :phone_number, :availability_schedule)";
            $stmtTrainer = $pdo->prepare($sqlTrainer);
            $stmtTrainer->execute([
                ':user_id'               => $user_id,
                ':full_name'             => $full_name,
                ':specialization'        => $specialization,
                ':email'                 => $email,
                ':phone_number'          => $phone_number,
                ':availability_schedule' => $availability,
            ]);

            $pdo->commit();
            $message = 'Trainer created successfully.';
            $action  = 'list';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Error creating trainer: ' . $e->getMessage();
        }
    }
}

// EDIT TRAINER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'edit') {
    $trainer_id     = $_POST['trainer_id'] ?? null;
    $username       = trim($_POST['username'] ?? '');
    $full_name      = trim($_POST['full_name'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $phone_number   = trim($_POST['phone_number'] ?? '');
    $specialization = trim($_POST['specialization'] ?? '');
    $availability   = trim($_POST['availability_schedule'] ?? '');

    if (!$trainer_id || $username === '' || $full_name === '') {
        $error = 'Trainer ID, username and full name are required.';
    } else {
        $trainer = getTrainerById($pdo, $trainer_id);
        if (!$trainer) {
            $error = 'Trainer not found.';
        } else {
            try {
                $pdo->beginTransaction();

                // 1) Update users
                $sqlUser = "UPDATE users
                            SET username = :username, full_name = :full_name, email = :email
                            WHERE user_id = :user_id";
                $stmtUser = $pdo->prepare($sqlUser);
                $stmtUser->execute([
                    ':username'  => $username,
                    ':full_name' => $full_name,
                    ':email'     => $email,
                    ':user_id'   => $trainer['user_id'],
                ]);

                // 2) Update trainers
                $sqlTrainer = "UPDATE trainers
                               SET full_name = :full_name,
                                   specialization = :specialization,
                                   email = :email,
                                   phone_number = :phone_number,
                                   availability_schedule = :availability_schedule
                               WHERE trainer_id = :trainer_id";
                $stmtTrainer = $pdo->prepare($sqlTrainer);
                $stmtTrainer->execute([
                    ':full_name'             => $full_name,
                    ':specialization'        => $specialization,
                    ':email'                 => $email,
                    ':phone_number'          => $phone_number,
                    ':availability_schedule' => $availability,
                    ':trainer_id'            => $trainer_id,
                ]);

                $pdo->commit();
                $message = 'Trainer updated successfully.';
                $action  = 'list';
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = 'Error updating trainer: ' . $e->getMessage();
            }
        }
    }
}

// DELETE TRAINER
if ($action === 'delete' && isset($_GET['id'])) {
    $trainer_id = (int) $_GET['id'];

    $trainer = getTrainerById($pdo, $trainer_id);
    if ($trainer) {
        try {
            $pdo->beginTransaction();

            // delete user -> cascade delete trainer row
            $sqlDeleteUser = "DELETE FROM users WHERE user_id = :user_id";
            $stmtDelete = $pdo->prepare($sqlDeleteUser);
            $stmtDelete->execute([':user_id' => $trainer['user_id']]);

            $pdo->commit();
            $message = 'Trainer deleted successfully.';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Error deleting trainer: ' . $e->getMessage();
        }
    } else {
        $error = 'Trainer not found.';
    }

    $action = 'list';
}

/**
 * FETCH DATA
 */
$trainers = [];

if ($action === 'list') {
    $sql = "SELECT t.trainer_id, t.full_name, u.username, t.email, t.specialization, t.phone_number
            FROM trainers t
            JOIN users u ON t.user_id = u.user_id
            ORDER BY t.trainer_id DESC";
    $stmt = $pdo->query($sql);
    $trainers = $stmt->fetchAll();
}

$editTrainer = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $editTrainer = getTrainerById($pdo, (int) $_GET['id']);
    if (!$editTrainer) {
        $error  = 'Trainer not found.';
        $action = 'list';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin - Trainer Management</title>

    <style>
        :root{
            --bg:#0b0b0f;
            --text:#e5e7eb;
            --muted:#9ca3af;
            --card:rgba(255,255,255,.04);
            --line:rgba(255,255,255,.08);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
        }

        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* Topnav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;
            border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{
            display:flex;
            align-items:center;
            gap:10px;
        }
        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.05); }
        .btn-danger{
            background: rgba(185,28,28,.85);
            border-color: rgba(185,28,28,.35);
        }
        .btn-danger:hover{ filter: brightness(1.05); }

        /* Main */
        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }

        h1{
            margin:0;
            font-size: 20px;
        }
        .small{
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 13px;
        }

        .msg{
            border-radius: 12px;
            padding: 10px 12px;
            font-size: 13px;
            margin-top: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.05);
        }
        .msg-success{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .msg-error{ border-color: rgba(185,28,28,.35); background: rgba(185,28,28,.12); }

        .box{
            margin-top: 14px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }

        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 12px;
            overflow:hidden;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{
            background: rgba(255,255,255,.02);
        }

        /* forms */
        form{ margin-top: 10px; }
        .form-grid{
            display:grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 12px 16px;
        }
        .form-group{
            display:flex;
            flex-direction: column;
            gap:6px;
        }
        label{
            font-size: 12px;
            letter-spacing:.04em;
            color: #cfd3df;
        }
        input, textarea{
            padding: 10px 10px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.35);
            color: var(--text);
        }
        input:focus, textarea:focus{
            outline:none;
            border-color: rgba(124,140,255,.7);
            box-shadow: 0 0 0 3px rgba(124,140,255,.15);
        }
        textarea{
            min-height: 80px;
            resize: vertical;
        }
        .actions{
            margin-top: 14px;
            display:flex;
            gap:10px;
            flex-wrap:wrap;
        }

        @media (max-width: 980px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .form-grid{ grid-template-columns: 1fr; }
            table{ font-size: 12px; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Trainer Management</span>
    </div>
    <div class="navright">
        <a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Trainer Management</h1>
                <p class="small">Logged in as: <?php echo htmlspecialchars($adminName); ?> (Admin)</p>
            </div>

            <?php if ($action === 'list'): ?>
                <div>
                    <a href="admin_trainers.php?action=add" class="btn btn-primary">+ Add New Trainer</a>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($message): ?>
            <div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="box">

            <?php if ($action === 'list'): ?>

                <?php if (count($trainers) === 0): ?>
                    <p class="small">No trainers found.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Specialization</th>
                            <th>Phone</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($trainers as $t): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($t['trainer_id']); ?></td>
                                <td><?php echo htmlspecialchars($t['username']); ?></td>
                                <td><?php echo htmlspecialchars($t['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($t['email']); ?></td>
                                <td><?php echo htmlspecialchars($t['specialization']); ?></td>
                                <td><?php echo htmlspecialchars($t['phone_number']); ?></td>
                                <td style="display:flex; gap:8px; flex-wrap:wrap;">
                                    <a class="btn" href="admin_trainers.php?action=edit&id=<?php echo $t['trainer_id']; ?>">Edit</a>
                                    <a class="btn btn-danger"
                                       href="admin_trainers.php?action=delete&id=<?php echo $t['trainer_id']; ?>"
                                       onclick="return confirm('Are you sure you want to delete this trainer?');">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

            <?php elseif ($action === 'add'): ?>

                <h2 style="margin:0 0 8px;">Add New Trainer</h2>
                <p class="small"><a href="admin_trainers.php" style="color: var(--accent2); text-decoration:none;">← Back to list</a></p>

                <form method="POST" action="admin_trainers.php?action=add">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="username">Username *</label>
                            <input type="text" id="username" name="username" required>
                        </div>

                        <div class="form-group">
                            <label for="password">Password *</label>
                            <input type="password" id="password" name="password" required>
                        </div>

                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" id="full_name" name="full_name" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email">
                        </div>

                        <div class="form-group">
                            <label for="phone_number">Phone Number</label>
                            <input type="text" id="phone_number" name="phone_number">
                        </div>

                        <div class="form-group">
                            <label for="specialization">Specialization</label>
                            <input type="text" id="specialization" name="specialization" placeholder="e.g. Weight Training, Yoga">
                        </div>

                        <div class="form-group" style="grid-column: span 2;">
                            <label for="availability_schedule">Availability Schedule</label>
                            <textarea id="availability_schedule" name="availability_schedule" placeholder="e.g. Mon-Fri 9am-6pm"></textarea>
                        </div>
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn btn-primary">Save Trainer</button>
                        <a href="admin_trainers.php" class="btn">Cancel</a>
                    </div>
                </form>

            <?php elseif ($action === 'edit' && $editTrainer): ?>

                <h2 style="margin:0 0 8px;">Edit Trainer</h2>
                <p class="small"><a href="admin_trainers.php" style="color: var(--accent2); text-decoration:none;">← Back to list</a></p>

                <form method="POST" action="admin_trainers.php?action=edit">
                    <input type="hidden" name="trainer_id" value="<?php echo htmlspecialchars($editTrainer['trainer_id']); ?>">

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="username">Username *</label>
                            <input type="text" id="username" name="username" required
                                   value="<?php echo htmlspecialchars($editTrainer['username']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" id="full_name" name="full_name" required
                                   value="<?php echo htmlspecialchars($editTrainer['full_name']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email"
                                   value="<?php echo htmlspecialchars($editTrainer['email']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="phone_number">Phone Number</label>
                            <input type="text" id="phone_number" name="phone_number"
                                   value="<?php echo htmlspecialchars($editTrainer['phone_number']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="specialization">Specialization</label>
                            <input type="text" id="specialization" name="specialization"
                                   value="<?php echo htmlspecialchars($editTrainer['specialization']); ?>">
                        </div>

                        <div class="form-group" style="grid-column: span 2;">
                            <label for="availability_schedule">Availability Schedule</label>
                            <textarea id="availability_schedule" name="availability_schedule"><?php
                                echo htmlspecialchars($editTrainer['availability_schedule']);
                            ?></textarea>
                        </div>
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn btn-primary">Update Trainer</button>
                        <a href="admin_trainers.php" class="btn">Cancel</a>
                    </div>
                </form>

            <?php endif; ?>

        </div>
    </div>
</div>

</body>
</html>
