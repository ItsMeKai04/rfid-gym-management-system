<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Trainer') {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$stmt   = $pdo->prepare("SELECT * FROM trainers WHERE user_id = :uid LIMIT 1");
$stmt->execute([':uid'=>$userId]);
$trainer = $stmt->fetch();
if (!$trainer) die('Trainer not found.');
$trainerId = $trainer['trainer_id'];

$action  = $_GET['action'] ?? 'list';
$message = '';
$error   = '';

// assigned members
$sqlMembers = "
    SELECT m.member_id, m.full_name
    FROM member_trainer_assigned a
    JOIN members m ON a.member_id = m.member_id
    WHERE a.trainer_id = :tid
    ORDER BY m.full_name
";
$stmt = $pdo->prepare($sqlMembers);
$stmt->execute([':tid'=>$trainerId]);
$members = $stmt->fetchAll();

// ADD log
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
    $member_id  = (int)($_POST['member_id'] ?? 0);
    $weight_kg  = $_POST['weight_kg'] !== '' ? (float)$_POST['weight_kg'] : null;
    $height_cm  = $_POST['height_cm'] !== '' ? (float)$_POST['height_cm'] : null;
    $body_fat   = $_POST['body_fat_percentage'] !== '' ? (float)$_POST['body_fat_percentage'] : null;
    $bmi        = $_POST['bmi'] !== '' ? (float)$_POST['bmi'] : null;
    $notes      = trim($_POST['notes'] ?? '');

    if ($member_id <= 0) {
        $error = 'Member is required.';
    } else {
        $sql = "INSERT INTO member_progress
                (member_id, trainer_id, weight_kg, height_cm, body_fat_percentage, bmi, notes)
                VALUES
                (:member_id, :trainer_id, :weight_kg, :height_cm, :body_fat, :bmi, :notes)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':member_id' => $member_id,
            ':trainer_id'=> $trainerId,
            ':weight_kg' => $weight_kg,
            ':height_cm' => $height_cm,
            ':body_fat'  => $body_fat,
            ':bmi'       => $bmi,
            ':notes'     => $notes,
        ]);
        $message = 'Progress log added.';
        $action  = 'list';
    }
}

// list logs (latest 50)
$logs = [];
if ($action === 'list') {
    $sql = "
        SELECT p.*, m.full_name AS member_name
        FROM member_progress p
        JOIN members m ON p.member_id = m.member_id
        WHERE p.trainer_id = :tid
        ORDER BY p.recorded_at DESC
        LIMIT 50
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':tid'=>$trainerId]);
    $logs = $stmt->fetchAll();
}

function nf($v, $dec = 1) {
    if ($v === null || $v === '') return '-';
    if (!is_numeric($v)) return htmlspecialchars((string)$v);
    return number_format((float)$v, $dec);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Trainer - Member Progress</title>
    <style>
        :root{
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
            --danger:#b91c1c;
        }
        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* top sticky nav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.06); }

        .container{
            width: min(1100px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{ margin:0; font-size: 20px; }
        .small{ margin: 6px 0 0; color: var(--muted); font-size: 13px; }

        /* messages */
        .msg{
            margin-top: 12px;
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            font-size: 13px;
        }
        .msg-success{ border-color: rgba(22,163,74,.25); background: rgba(22,163,74,.10); }
        .msg-error{ border-color: rgba(185,28,28,.25); background: rgba(185,28,28,.10); }

        .section-title{ margin: 16px 0 6px; font-size: 16px; }
        .hint{ margin: 0 0 10px; color: var(--muted); font-size: 12px; }

        /* form */
        .form-grid{
            margin-top: 12px;
            display:grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px 14px;
        }
        .form-group{ display:flex; flex-direction:column; gap:6px; }
        label{ font-size: 12px; color: var(--muted); letter-spacing: .03em; }
        input, select, textarea{
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.25);
            color: var(--text);
        }
        textarea{ min-height: 110px; resize: vertical; }
        input:focus, select:focus, textarea:focus{
            outline:none;
            border-color: rgba(124,140,255,.55);
            box-shadow: 0 0 0 3px rgba(124,140,255,.12);
        }
        .span3{ grid-column: span 3; }
        .form-actions{
            margin-top: 14px;
            display:flex;
            gap:10px;
            flex-wrap:wrap;
        }

        /* table */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 14px;
            overflow:hidden;
            margin-top: 12px;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{ background: rgba(255,255,255,.02); }
        .notes{
            max-width: 520px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        @media (max-width: 900px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .form-grid{ grid-template-columns: 1fr; }
            .span3{ grid-column: auto; }
            .notes{ max-width: 240px; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Trainer</span>
    </div>

    <div class="navright">
        <a href="trainer_dashboard.php" class="btn">← Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Member Progress Tracking</h1>
                <p class="small">Log and monitor your members’ performance data.</p>
            </div>
        </div>

        <?php if ($message): ?><div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <h2 class="section-title">Add Progress Log</h2>

        <?php if (count($members) === 0): ?>
            <p class="hint">No assigned members. Ask admin to assign members to you.</p>
        <?php else: ?>
            <form method="POST" action="trainer_progress.php?action=add">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="member_id">Member *</label>
                        <select id="member_id" name="member_id" required>
                            <option value="">-- Select Member --</option>
                            <?php foreach ($members as $m): ?>
                                <option value="<?php echo $m['member_id']; ?>">
                                    <?php echo htmlspecialchars($m['full_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="weight_kg">Weight (kg)</label>
                        <input type="number" step="0.1" name="weight_kg" id="weight_kg" placeholder="e.g. 75.5">
                    </div>

                    <div class="form-group">
                        <label for="height_cm">Height (cm)</label>
                        <input type="number" step="0.1" name="height_cm" id="height_cm" placeholder="e.g. 175">
                    </div>

                    <div class="form-group">
                        <label for="body_fat_percentage">Body Fat (%)</label>
                        <input type="number" step="0.1" name="body_fat_percentage" id="body_fat_percentage" placeholder="e.g. 18.2">
                    </div>

                    <div class="form-group">
                        <label for="bmi">BMI</label>
                        <input type="number" step="0.1" name="bmi" id="bmi" placeholder="e.g. 24.6">
                    </div>

                    <div class="form-group span3">
                        <label for="notes">Notes</label>
                        <textarea id="notes" name="notes" placeholder="Write short notes (progress, issues, next plan)..."></textarea>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Save Log</button>
                </div>
            </form>
        <?php endif; ?>

        <h2 class="section-title" style="margin-top:18px;">Recent Progress Logs</h2>

        <?php if (count($logs) === 0): ?>
            <p class="hint">No progress logs found.</p>
        <?php else: ?>
            <table>
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Member</th>
                    <th>Weight</th>
                    <th>Height</th>
                    <th>Body Fat</th>
                    <th>BMI</th>
                    <th>Notes</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($logs as $l): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($l['recorded_at']); ?></td>
                        <td><?php echo htmlspecialchars($l['member_name']); ?></td>
                        <td><?php echo nf($l['weight_kg'], 1); ?></td>
                        <td><?php echo nf($l['height_cm'], 1); ?></td>
                        <td><?php echo nf($l['body_fat_percentage'], 1); ?></td>
                        <td><?php echo nf($l['bmi'], 1); ?></td>
                        <td class="notes" title="<?php echo htmlspecialchars($l['notes'] ?? ''); ?>">
                            <?php echo htmlspecialchars($l['notes'] ?? '-'); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

    </div>
</div>

</body>
</html>
