<?php
session_start();
require_once 'db.php';

$error = "";
$success = "";

function clean($v) {
    return trim((string)$v);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username   = clean($_POST['username'] ?? '');
    $full_name  = clean($_POST['full_name'] ?? '');
    $email      = clean($_POST['email'] ?? '');
    $phone      = clean($_POST['phone_number'] ?? '');
    $dob        = clean($_POST['date_of_birth'] ?? '');
    $password   = (string)($_POST['password'] ?? '');
    $confirm    = (string)($_POST['confirm_password'] ?? '');

    if ($username === '' || $full_name === '' || $email === '' || $password === '' || $confirm === '') {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (strlen($username) < 4) {
        $error = "Username must be at least 4 characters.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($password !== $confirm) {
        $error = "Password and Confirm Password do not match.";
    } else {
        // Optional: validate DOB format if provided
        if ($dob !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
            $error = "Date of birth must be in YYYY-MM-DD format.";
        } else {
            try {
                // Check duplicates (username/email)
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = :u OR email = :e");
                $stmt->execute([':u' => $username, ':e' => $email]);
                if ($stmt->fetchColumn() > 0) {
                    $error = "Username or email already exists.";
                } else {
                    $pdo->beginTransaction();

                    // Use password_hash (better than SHA2)
                    $hash = password_hash($password, PASSWORD_DEFAULT);

                    // Create user as Member
                    $stmtUser = $pdo->prepare("
                        INSERT INTO users (username, password_hash, full_name, email, role, status)
                        VALUES (:username, :password_hash, :full_name, :email, 'Member', 'Active')
                    ");
                    $stmtUser->execute([
                        ':username'      => $username,
                        ':password_hash' => $hash,
                        ':full_name'     => $full_name,
                        ':email'         => $email
                    ]);

                    $user_id = (int)$pdo->lastInsertId();

                    // Create member profile (membership fields auto-handled)
                    $stmtMember = $pdo->prepare("
                        INSERT INTO members (user_id, full_name, date_of_birth, email, phone_number, membership_status, join_date, expiry_date)
                        VALUES (:user_id, :full_name, :dob, :email, :phone, 'Pending', CURRENT_DATE, NULL)
                    ");
                    $stmtMember->execute([
                        ':user_id'   => $user_id,
                        ':full_name' => $full_name,
                        ':dob'       => ($dob === '' ? null : $dob),
                        ':email'     => $email,
                        ':phone'     => ($phone === '' ? null : $phone)
                    ]);

                    $pdo->commit();
                    $success = "Account created successfully! You can now login.";
                }
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error = "Error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register - Gym System</title>
  <style>
  * { box-sizing: border-box; }

  body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: radial-gradient(ellipse at top, #0b1b36 0%, #050814 55%, #02040b 100%);
    color: #fff;
    min-height: 100vh;
    display: grid;
    place-items: center;
    padding: 22px;
  }

  .card {
    width: 640px;                 /* wider to avoid cramped look */
    max-width: 100%;
    background: rgba(10, 18, 40, 0.55);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 14px;
    padding: 28px;
    box-shadow: 0 18px 45px rgba(0,0,0,0.45);
    backdrop-filter: blur(10px);
  }

  h1 {
    margin: 0 0 6px;
    font-size: 28px;
    letter-spacing: 0.2px;
  }

  p.sub {
    margin: 0 0 22px;
    color: rgba(255,255,255,0.7);
    font-size: 13px;
    line-height: 1.4;
  }

  .grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px 18px;              /* more breathing space */
  }

  .field {
    display: flex;
    flex-direction: column;
  }

  label {
    font-size: 12px;
    color: rgba(255,255,255,0.75);
    margin-bottom: 8px;
  }

  input {
    width: 100%;
    height: 44px;                 /* consistent height */
    padding: 0 12px;
    border-radius: 10px;
    border: 1px solid rgba(255,255,255,0.12);
    background: rgba(0,0,0,0.25);
    color: #fff;
    outline: none;
  }

  input::placeholder {
    color: rgba(255,255,255,0.35);
  }

  .full {
    grid-column: 1 / -1;
  }

  .btn {
    width: 100%;
    margin-top: 18px;
    height: 46px;
    border: none;
    border-radius: 10px;
    background: #5b67f0;
    color: #fff;
    font-weight: 700;
    cursor: pointer;
  }

  .btn:hover { filter: brightness(1.05); }

  .msg {
    margin-top: 12px;
    font-size: 13px;
    padding: 10px 12px;
    border-radius: 10px;
  }

  .error { background: rgba(239,68,68,0.18); border: 1px solid rgba(239,68,68,0.35); }
  .success { background: rgba(34,197,94,0.18); border: 1px solid rgba(34,197,94,0.35); }

  .bottom {
    margin-top: 14px;
    text-align: center;
    font-size: 13px;
    color: rgba(255,255,255,0.7);
  }

  .bottom a {
    color: #aab3ff;
    text-decoration: none;
    font-weight: 600;
  }

  /* Mobile: stack into 1 column */
  @media (max-width: 640px) {
    .card { padding: 22px; }
    .grid { grid-template-columns: 1fr; gap: 14px; }
    .full { grid-column: auto; }
  }
</style>

</head>
<body>
  <div class="card">
    <h1>Register</h1>
    <p class="sub">Create a Member account to access the system.</p>

    <form method="POST">
      <div class="grid">
        <div>
          <label>Username *</label>
          <input name="username" placeholder="e.g. member_ali" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
        </div>
        <div>
          <label>Email *</label>
          <input name="email" type="email" placeholder="e.g. ali@gmail.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>

        <div class="full">
          <label>Full Name *</label>
          <input name="full_name" placeholder="e.g. Ali Ahmad" required value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>">
        </div>

        <div>
          <label>Phone Number</label>
          <input name="phone_number" placeholder="e.g. 0123456789" value="<?= htmlspecialchars($_POST['phone_number'] ?? '') ?>">
        </div>
        <div>
          <label>Date of Birth</label>
          <input name="date_of_birth" type="date" value="<?= htmlspecialchars($_POST['date_of_birth'] ?? '') ?>">
        </div>

        <div>
          <label>Password *</label>
          <input name="password" type="password" placeholder="Min 6 characters" required>
        </div>
        <div>
          <label>Confirm Password *</label>
          <input name="confirm_password" type="password" placeholder="Re-enter password" required>
        </div>
      </div>

      <button class="btn" type="submit">Create Account</button>
    </form>

    <?php if ($error): ?>
      <div class="msg error"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
      <div class="msg success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <div class="bottom">
      Already have an account? <a href="login.php">Back to login</a>
    </div>
  </div>
</body>
</html>
