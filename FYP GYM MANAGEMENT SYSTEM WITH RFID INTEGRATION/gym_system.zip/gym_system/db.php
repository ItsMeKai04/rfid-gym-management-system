<?php
// db.php
$host = 'localhost';
$db   = 'gym_management_db';
$user = 'root';        // default XAMPP
$pass = '';            // default XAMPP (empty)
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // Kalau error sambungan
    die('Database connection failed: ' . $e->getMessage());
}
