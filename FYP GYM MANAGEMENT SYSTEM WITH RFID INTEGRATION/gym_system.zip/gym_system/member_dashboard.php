<?php
session_start();
require_once 'db.php';

// Only Member
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Member') {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

// Get user + member
$stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :id LIMIT 1");
$stmt->execute([':id' => $userId]);
$user = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM members WHERE user_id = :id LIMIT 1");
$stmt->execute([':id' => $userId]);
$member = $stmt->fetch();

if (!$member) {
    die('Member profile not found.');
}

$memberId   = $member['member_id'];
$currentTab = $_GET['tab'] ?? 'home';
$message    = '';
$error      = '';

/* ------------ PROFILE UPDATE (Profile Management) ------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_profile') {
    $full_name    = trim($_POST['full_name'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $phone_number = trim($_POST['phone_number'] ?? '');
    $dob          = $_POST['date_of_birth'] ?: null;

    if ($full_name === '') {
        $error = 'Full name is required.';
        $currentTab = 'profile';
    } else {
        try {
            $pdo->beginTransaction();

            // update users
            $stmt = $pdo->prepare("UPDATE users SET full_name = :full_name, email = :email WHERE user_id = :uid");
            $stmt->execute([
                ':full_name' => $full_name,
                ':email'     => $email,
                ':uid'       => $userId,
            ]);

            // update members
            $stmt = $pdo->prepare("
                UPDATE members 
                SET full_name = :full_name,
                    email = :email,
                    phone_number = :phone_number,
                    date_of_birth = :dob
                WHERE member_id = :mid
            ");
            $stmt->execute([
                ':full_name'    => $full_name,
                ':email'        => $email,
                ':phone_number' => $phone_number,
                ':dob'          => $dob,
                ':mid'          => $memberId,
            ]);

            $pdo->commit();
            $message = 'Profile updated successfully.';
            $currentTab = 'profile';

            // refresh data
            $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = :id LIMIT 1");
            $stmt->execute([':id' => $userId]);
            $user = $stmt->fetch();

            $stmt = $pdo->prepare("SELECT * FROM members WHERE user_id = :id LIMIT 1");
            $stmt->execute([':id' => $userId]);
            $member = $stmt->fetch();

        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Error updating profile: ' . $e->getMessage();
            $currentTab = 'profile';
        }
    }
}

/* ------------ DATA FOR DASHBOARD ------------ */

// Assigned trainer
$sql = "
    SELECT t.trainer_id, t.full_name 
    FROM member_trainer_assigned a
    JOIN trainers t ON a.trainer_id = t.trainer_id
    WHERE a.member_id = :mid
    LIMIT 1
";
$stmt = $pdo->prepare($sql);
$stmt->execute([':mid' => $memberId]);
$assignedTrainer = $stmt->fetch();

// Latest progress log
$sql = "
    SELECT * FROM member_progress
    WHERE member_id = :mid
    ORDER BY recorded_at DESC
    LIMIT 1
";
$stmt = $pdo->prepare($sql);
$stmt->execute([':mid' => $memberId]);
$latestProgress = $stmt->fetch();

// Attendance summary
$sql = "
    SELECT 
        COUNT(*) AS total_days,
        SUM(status = 'Present') AS present_days,
        SUM(status = 'Late') AS late_days
    FROM attendance
    WHERE member_id = :mid
";
$stmt = $pdo->prepare($sql);
$stmt->execute([':mid' => $memberId]);
$attendanceSummary = $stmt->fetch();

// Upcoming schedules
$today = date('Y-m-d');
$sql = "
    SELECT s.*, t.full_name AS trainer_name, w.title AS workout_title
    FROM schedules s
    LEFT JOIN trainers t ON s.trainer_id = t.trainer_id
    LEFT JOIN workouts w ON s.workout_id = w.workout_id
    WHERE s.member_id = :mid
      AND s.class_date >= :today
    ORDER BY s.class_date, s.start_time
    LIMIT 10
";
$stmt = $pdo->prepare($sql);
$stmt->execute([':mid' => $memberId, ':today' => $today]);
$upcomingSchedules = $stmt->fetchAll();

// Payment history
$sql = "
    SELECT * FROM payments
    WHERE member_id = :mid
    ORDER BY payment_date DESC, payment_id DESC
    LIMIT 20
";
$stmt = $pdo->prepare($sql);
$stmt->execute([':mid' => $memberId]);
$payments = $stmt->fetchAll();
$lastPayment = $payments[0] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Member Dashboard</title>
    <style>
        :root{
            --bg:#0b0b0f;
            --panel:#111114;
            --panel2:#0f1013;
            --card:#14141a;
            --card2:#151b25;
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --accent:#5b5ce6; /* same vibe as your index button */
            --accent2:#7c8cff;
            --danger:#b91c1c;
            --success:#16a34a;
            --warn:#d97706;
        }

        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background: radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                        radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                        linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* ===== TopNav (same style as your 2nd video) ===== */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            color: var(--accent2);
            font-size: 14px;
            letter-spacing:.02em;
            display:flex;
            align-items:center;
            gap:10px;
            user-select:none;
        }
        .brand .back{
            width:34px;height:34px;
            border-radius: 10px;
            display:grid;
            place-items:center;
            background: rgba(255,255,255,.06);
            border:1px solid rgba(255,255,255,.08);
            cursor:pointer;
            color: var(--text);
            font-size:16px;
        }
        .navlinks{
            display:flex;
            gap:22px;
            align-items:center;
            justify-content:center;
            flex:1;
        }
        .navlinks a{
            color: #eaeaf1;
            text-decoration:none;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .12em;
            opacity: .9;
            position: relative;
            padding: 8px 4px;
        }
        .navlinks a:hover{ opacity:1; }
        .navlinks a.active::after{
            content:"";
            position:absolute;
            left:0; right:0;
            bottom:-10px;
            height:2px;
            background: var(--accent2);
        }

        .navright{
            display:flex;
            align-items:center;
            gap:12px;
        }
        .logout{
            color:#fff;
            text-decoration:none;
            font-size:12px;
            padding: 9px 14px;
            border-radius:999px;
            border: 1px solid rgba(255,255,255,.14);
            background: rgba(255,255,255,.05);
        }
        .logout:hover{
            background: rgba(255,255,255,.10);
        }
        .avatar{
            width:36px;height:36px;
            border-radius:999px;
            display:grid;
            place-items:center;
            font-weight:700;
            background: rgba(91,92,230,.22);
            border: 1px solid rgba(124,140,255,.25);
            color:#fff;
        }

        /* ===== Layout ===== */
        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        /* Hero header panel */
        .hero{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px 18px 16px;
        }
        .hero-top{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:14px;
            flex-wrap:wrap;
        }
        .hero h1{
            margin: 0;
            font-size: 20px;
            letter-spacing:.02em;
        }
        .hero p{
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 13px;
        }

        /* Stat cards */
        .stats{
            margin-top:14px;
            display:grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 14px;
        }
        .card{
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 14px;
            padding: 14px 14px 12px;
        }
        .card h3{
            margin:0 0 8px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .12em;
            color: #cfd3df;
        }
        .value{
            font-size: 22px;
            font-weight: 800;
            margin-bottom:4px;
        }
        .hint{
            color: var(--muted);
            font-size: 12px;
            line-height: 1.4;
        }

        /* Content panel */
        .panel{
            margin-top: 16px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 18px;
        }
        .section-title{
            margin: 0 0 10px;
            font-size: 16px;
            letter-spacing:.02em;
        }
        .subtext{
            margin: 0 0 16px;
            font-size: 13px;
            color: var(--muted);
        }

        /* Tables */
        table{
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
            overflow:hidden;
            border-radius: 12px;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align:top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{
            background: rgba(255,255,255,.02);
        }

        /* Badges */
        .badge{
            display:inline-block;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 11px;
            border: 1px solid rgba(255,255,255,.12);
            background: rgba(255,255,255,.06);
        }
        .badge-paid{ background: rgba(22,163,74,.18); border-color: rgba(22,163,74,.35); }
        .badge-pending{ background: rgba(217,119,6,.18); border-color: rgba(217,119,6,.35); }
        .badge-overdue{ background: rgba(185,28,28,.20); border-color: rgba(185,28,28,.35); }

        /* Messages */
        .msg{
            border-radius: 12px;
            padding: 10px 12px;
            font-size: 13px;
            margin-bottom: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.05);
        }
        .msg-success{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .msg-error{ border-color: rgba(185,28,28,.35); background: rgba(185,28,28,.12); }

        /* Forms */
        .profile-grid{
            display:grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 12px 16px;
        }
        .form-group{
            display:flex;
            flex-direction:column;
            gap: 6px;
        }
        label{
            font-size: 12px;
            letter-spacing:.04em;
            color: #cfd3df;
        }
        input[type="text"], input[type="email"], input[type="date"]{
            padding: 10px 10px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.35);
            color: var(--text);
        }
        input:focus{
            outline:none;
            border-color: rgba(124,140,255,.7);
            box-shadow: 0 0 0 3px rgba(124,140,255,.15);
        }
        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:8px;
            cursor:pointer;
            border:none;
            border-radius: 999px;
            padding: 10px 16px;
            color: #fff;
            background: var(--accent);
            font-size: 13px;
            font-weight: 700;
        }
        .btn:hover{ filter: brightness(1.05); }
        .btn:active{ transform: translateY(1px); }

        /* Home split grid */
        .split{
            display:grid;
            grid-template-columns: 1.6fr 1fr;
            gap: 16px;
        }
        .box{
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,.06);
            background: rgba(255,255,255,.03);
            padding: 14px;
        }
        .box h3{
            margin:0 0 10px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .12em;
            color:#cfd3df;
        }

        @media (max-width: 980px){
            .stats{ grid-template-columns:1fr; }
            .split{ grid-template-columns:1fr; }
            .navlinks{ display:none; } /* on small screen hide links (optional) */
            .profile-grid{ grid-template-columns:1fr; }
            .topnav{ padding: 0 14px; }
            .container{ width: calc(100% - 24px); }
        }
    </style>
</head>
<body>

<!-- TOP NAV -->
<div class="topnav">
    <div class="brand">
        <div class="back" onclick="window.history.back();">←</div>
        <span>GymBroz</span>
    </div>

    <div class="navlinks">
        <a href="member_dashboard.php?tab=home" class="<?php echo $currentTab==='home'?'active':''; ?>">Home</a>
        <a href="member_dashboard.php?tab=fitness" class="<?php echo $currentTab==='fitness'?'active':''; ?>">Fitness Summary</a>
        <a href="member_dashboard.php?tab=membership" class="<?php echo $currentTab==='membership'?'active':''; ?>">Membership</a>
        <a href="member_dashboard.php?tab=workout" class="<?php echo $currentTab==='workout'?'active':''; ?>">Workout</a>
        <a href="member_dashboard.php?tab=profile" class="<?php echo $currentTab==='profile'?'active':''; ?>">Profile</a>
    </div>

    <div class="navright">
        <a href="logout.php" class="logout">Logout</a>
        <div class="avatar">
            <?php echo strtoupper(substr($member['full_name'] ?? 'M', 0, 1)); ?>
        </div>
    </div>
</div>

<div class="container">

    <!-- HERO / TOP PANEL -->
    <div class="hero">
        <div class="hero-top">
            <div>
                <h1>Welcome back, <?php echo htmlspecialchars($member['full_name']); ?> 👋</h1>
                <p>Here’s your latest membership, training, and progress overview.</p>
            </div>
        </div>

        <div class="stats">
            <div class="card">
                <h3>Assigned Trainer</h3>
                <div class="value">
                    <?php echo $assignedTrainer ? htmlspecialchars($assignedTrainer['full_name']) : 'Not Assigned'; ?>
                </div>
                <div class="hint">Your primary trainer for this membership.</div>
            </div>

            <div class="card">
                <h3>Membership Status</h3>
                <div class="value"><?php echo htmlspecialchars($member['membership_status']); ?></div>
                <div class="hint">
                    Join: <?php echo htmlspecialchars($member['join_date']); ?> |
                    Expiry: <?php echo htmlspecialchars($member['expiry_date']); ?>
                </div>
            </div>

            <div class="card">
                <h3>Last Workout Progress</h3>
                <?php if ($latestProgress): ?>
                    <div class="value"><?php echo htmlspecialchars($latestProgress['weight_kg']); ?> kg</div>
                    <div class="hint">
                        BMI: <?php echo htmlspecialchars($latestProgress['bmi']); ?> |
                        Date: <?php echo htmlspecialchars($latestProgress['recorded_at']); ?>
                    </div>
                <?php else: ?>
                    <div class="value">No data</div>
                    <div class="hint">Your trainer has not logged progress yet.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- CONTENT PANEL -->
    <div class="panel">

        <?php if ($message): ?>
            <div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($currentTab === 'home'): ?>

            <h2 class="section-title">Overview</h2>
            <p class="subtext">Quick view of your upcoming sessions, attendance, and latest payment.</p>

            <div class="split">
                <div class="box">
                    <h3>Upcoming Sessions</h3>
                    <?php if (count($upcomingSchedules) === 0): ?>
                        <p class="subtext" style="margin:0;">No upcoming sessions scheduled.</p>
                    <?php else: ?>
                        <table>
                            <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Trainer</th>
                                <th>Workout</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($upcomingSchedules as $s): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($s['class_date']); ?></td>
                                    <td><?php echo htmlspecialchars($s['start_time'] . ' - ' . $s['end_time']); ?></td>
                                    <td><?php echo htmlspecialchars($s['trainer_name']); ?></td>
                                    <td><?php echo htmlspecialchars($s['workout_title']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <div class="box">
                    <h3>Attendance Summary</h3>
                    <table>
                        <tbody>
                        <tr>
                            <th>Total Days</th>
                            <td><?php echo (int)($attendanceSummary['total_days'] ?? 0); ?></td>
                        </tr>
                        <tr>
                            <th>Present</th>
                            <td><?php echo (int)($attendanceSummary['present_days'] ?? 0); ?></td>
                        </tr>
                        <tr>
                            <th>Late</th>
                            <td><?php echo (int)($attendanceSummary['late_days'] ?? 0); ?></td>
                        </tr>
                        </tbody>
                    </table>

                    <div style="height:12px;"></div>

                    <h3>Latest Payment</h3>
                    <?php if ($lastPayment): ?>
                        <table>
                            <tbody>
                            <tr>
                                <th>Amount</th>
                                <td>RM <?php echo number_format($lastPayment['amount'], 2); ?></td>
                            </tr>
                            <tr>
                                <th>Date</th>
                                <td><?php echo htmlspecialchars($lastPayment['payment_date']); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td>
                                    <?php
                                    $st  = $lastPayment['payment_status'];
                                    if ($st === 'Paid') $cls = 'badge badge-paid';
                                    elseif ($st === 'Pending') $cls = 'badge badge-pending';
                                    else $cls = 'badge badge-overdue';
                                    ?>
                                    <span class="<?php echo $cls; ?>"><?php echo htmlspecialchars($st); ?></span>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="subtext" style="margin:0;">No payment records.</p>
                    <?php endif; ?>
                </div>
            </div>

        <?php elseif ($currentTab === 'fitness'): ?>

            <h2 class="section-title">Fitness Summary</h2>
            <p class="subtext">Summary of your logged progress.</p>

            <table>
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Weight (kg)</th>
                    <th>Height (cm)</th>
                    <th>BMI</th>
                    <th>Body Fat (%)</th>
                    <th>Notes</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $stmt = $pdo->prepare("
                    SELECT * FROM member_progress
                    WHERE member_id = :mid
                    ORDER BY recorded_at DESC
                    LIMIT 30
                ");
                $stmt->execute([':mid' => $memberId]);
                $allProgress = $stmt->fetchAll();

                if (count($allProgress) === 0): ?>
                    <tr><td colspan="6" class="subtext">No progress logs yet.</td></tr>
                <?php else:
                    foreach ($allProgress as $p): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($p['recorded_at']); ?></td>
                            <td><?php echo htmlspecialchars($p['weight_kg']); ?></td>
                            <td><?php echo htmlspecialchars($p['height_cm']); ?></td>
                            <td><?php echo htmlspecialchars($p['bmi']); ?></td>
                            <td><?php echo htmlspecialchars($p['body_fat_percentage']); ?></td>
                            <td><?php echo nl2br(htmlspecialchars($p['notes'])); ?></td>
                        </tr>
                    <?php endforeach;
                endif; ?>
                </tbody>
            </table>

        <?php elseif ($currentTab === 'membership'): ?>

            <h2 class="section-title">Payment & Subscription</h2>
            <p class="subtext">View your payment history and membership period.</p>

            <table>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Amount (RM)</th>
                    <th>Payment Date</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th>Receipt No.</th>
                </tr>
                </thead>
                <tbody>
                <?php if (count($payments) === 0): ?>
                    <tr><td colspan="6" class="subtext">No payment records.</td></tr>
                <?php else: ?>
                    <?php foreach ($payments as $p): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($p['payment_id']); ?></td>
                            <td><?php echo number_format($p['amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($p['payment_date']); ?></td>
                            <td><?php echo htmlspecialchars($p['due_date']); ?></td>
                            <td>
                                <?php
                                $st  = $p['payment_status'];
                                if ($st === 'Paid') $cls = 'badge badge-paid';
                                elseif ($st === 'Pending') $cls = 'badge badge-pending';
                                else $cls = 'badge badge-overdue';
                                ?>
                                <span class="<?php echo $cls; ?>"><?php echo htmlspecialchars($st); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($p['receipt_number']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>

        <?php elseif ($currentTab === 'workout'): ?>

            <h2 class="section-title">Workout & Schedule Viewer</h2>
            <p class="subtext">View your upcoming training sessions and workout plans.</p>

            <div class="box" style="margin-bottom:14px;">
                <h3>Upcoming Sessions</h3>
                <?php if (count($upcomingSchedules) === 0): ?>
                    <p class="subtext" style="margin:0;">No upcoming sessions scheduled.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Trainer</th>
                            <th>Workout</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($upcomingSchedules as $s): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($s['class_date']); ?></td>
                                <td><?php echo htmlspecialchars($s['start_time'] . ' - ' . $s['end_time']); ?></td>
                                <td><?php echo htmlspecialchars($s['trainer_name']); ?></td>
                                <td><?php echo htmlspecialchars($s['workout_title']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="box">
                <h3>Workout Plans Created For You</h3>
                <?php
                $sql = "
                    SELECT DISTINCT w.*
                    FROM schedules s
                    JOIN workouts w ON s.workout_id = w.workout_id
                    WHERE s.member_id = :mid
                    ORDER BY w.workout_id DESC
                ";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':mid' => $memberId]);
                $workoutPlans = $stmt->fetchAll();
                ?>
                <?php if (count($workoutPlans) === 0): ?>
                    <p class="subtext" style="margin:0;">No workout plans assigned yet.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>Difficulty</th>
                            <th>Description</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($workoutPlans as $w): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($w['title']); ?></td>
                                <td><?php echo htmlspecialchars($w['difficulty']); ?></td>
                                <td><?php echo nl2br(htmlspecialchars($w['description'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

        <?php elseif ($currentTab === 'profile'): ?>

            <h2 class="section-title">Profile Management</h2>
            <p class="subtext">Update your personal details and contact information.</p>

            <form method="POST" action="member_dashboard.php?tab=profile">
                <input type="hidden" name="action" value="update_profile">

                <div class="profile-grid">
                    <div class="form-group">
                        <label for="full_name">Full Name *</label>
                        <input type="text" id="full_name" name="full_name"
                               value="<?php echo htmlspecialchars($member['full_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email"
                               value="<?php echo htmlspecialchars($member['email']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="phone_number">Phone Number</label>
                        <input type="text" id="phone_number" name="phone_number"
                               value="<?php echo htmlspecialchars($member['phone_number']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="date_of_birth">Date of Birth</label>
                        <input type="date" id="date_of_birth" name="date_of_birth"
                               value="<?php echo htmlspecialchars($member['date_of_birth']); ?>">
                    </div>
                </div>

                <div style="margin-top:14px;">
                    <button type="submit" class="btn">Save Changes</button>
                </div>
            </form>

        <?php endif; ?>

    </div>
</div>

</body>
</html>
