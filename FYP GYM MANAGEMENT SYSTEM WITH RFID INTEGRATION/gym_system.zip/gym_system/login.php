<?php
session_start();
require_once 'db.php';

$error = "";

// If already logged in, redirect by role
if (!empty($_SESSION['role'])) {
    if ($_SESSION['role'] === 'Admin') {
        header("Location: admin_dashboard.php");
        exit;
    } elseif ($_SESSION['role'] === 'Trainer') {
        header("Location: trainer_dashboard.php");
        exit;
    } elseif ($_SESSION['role'] === 'Member') {
        header("Location: member_dashboard.php");
        exit;
    }
}

function clean($v) {
    return trim((string)$v);
}

/**
 * Supports BOTH:
 * - password_hash() (bcrypt/argon) => password_verify
 * - legacy SHA2('pass',256) stored as 64 hex chars => hash('sha256', pass)
 */
function verifyPasswordCompatible(string $inputPassword, string $storedHash): bool {
    $storedHash = trim($storedHash);

    // Legacy SHA-256 hex hash (64 chars)
    if (preg_match('/^[a-f0-9]{64}$/i', $storedHash)) {
        $inputSha = hash('sha256', $inputPassword);
        return hash_equals(strtolower($storedHash), strtolower($inputSha));
    }

    // Modern password_hash()
    return password_verify($inputPassword, $storedHash);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = clean($_POST['username'] ?? '');
    $password = (string)($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        $error = "Please enter username and password.";
    } else {
        $stmt = $pdo->prepare("
            SELECT user_id, username, password_hash, full_name, email, role, status
            FROM users
            WHERE username = :u
            LIMIT 1
        ");
        $stmt->execute([':u' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $error = "Invalid username or password.";
        } elseif (($user['status'] ?? 'Active') !== 'Active') {
            $error = "Your account is inactive. Please contact admin.";
        } else {
            if (!verifyPasswordCompatible($password, (string)$user['password_hash'])) {
                $error = "Invalid username or password.";
            } else {
                // Save session
                $_SESSION['user_id']  = (int)$user['user_id'];
                $_SESSION['username'] = (string)$user['username'];
                $_SESSION['name']     = (string)($user['full_name'] ?? '');
                $_SESSION['email']    = (string)($user['email'] ?? '');
                $_SESSION['role']     = (string)$user['role'];

                // Redirect by role
                if ($_SESSION['role'] === 'Admin') {
                    header("Location: admin_dashboard.php");
                    exit;
                } elseif ($_SESSION['role'] === 'Trainer') {
                    header("Location: trainer_dashboard.php");
                    exit;
                } else {
                    header("Location: member_dashboard.php");
                    exit;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Gym Login</title>
  <style>
    body{
      margin:0;
      font-family: Arial, sans-serif;
      background: radial-gradient(ellipse at top, #0b1b36 0%, #050814 55%, #02040b 100%);
      color:#fff;
      min-height:100vh;
      display:grid;
      place-items:center;
    }
    .card{
      width:520px;
      max-width:calc(100% - 32px);
      background: rgba(10, 18, 40, 0.55);
      border: 1px solid rgba(255,255,255,0.08);
      border-radius: 14px;
      padding: 28px;
      box-shadow: 0 18px 45px rgba(0,0,0,0.45);
      backdrop-filter: blur(10px);
    }
    h1{
      margin:0 0 8px;
      font-size:28px;
      letter-spacing:.2px;
    }
    .sub{
      margin:0 0 18px;
      color: rgba(255,255,255,0.7);
      font-size:13px;
    }
    label{
      font-size:12px;
      color: rgba(255,255,255,0.75);
      display:block;
      margin:12px 0 6px;
    }
    input{
      width:100%;
      padding:11px 12px;
      border-radius:10px;
      border: 1px solid rgba(255,255,255,0.12);
      background: rgba(0,0,0,0.25);
      color:#fff;
      outline:none;
    }
    input::placeholder{ color: rgba(255,255,255,0.35); }
    .btn{
      width:100%;
      margin-top:16px;
      padding:12px 14px;
      border:none;
      border-radius:10px;
      background:#5b67f0;
      color:#fff;
      font-weight:700;
      cursor:pointer;
    }
    .btn:hover{ filter:brightness(1.05); }
    .links{
      margin-top:12px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      font-size:13px;
      color: rgba(255,255,255,0.7);
    }
    .links a{
      color:#aab3ff;
      text-decoration:none;
      font-weight:600;
    }
    .msg{
      margin-top:12px;
      font-size:13px;
      padding:10px 12px;
      border-radius:10px;
      background: rgba(239,68,68,0.18);
      border: 1px solid rgba(239,68,68,0.35);
    }
    .test{
      margin-top:14px;
      font-size:12px;
      color: rgba(255,255,255,0.65);
      line-height:1.7;
    }
    .chip{
      display:inline-block;
      padding:2px 8px;
      border-radius:8px;
      background: rgba(255,255,255,0.07);
      border: 1px solid rgba(255,255,255,0.10);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono","Courier New", monospace;
      color: rgba(255,255,255,0.85);
      font-size:12px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>Gym Login</h1>
    <p class="sub">Login to access Admin / Trainer / Member dashboard.</p>

    <form method="POST" autocomplete="off">
      <label>Username</label>
      <input name="username" placeholder="Enter your username" required value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">

      <label>Password</label>
      <input name="password" type="password" placeholder="Enter your password" required>

      <button class="btn" type="submit">Login</button>
    </form>

    <div class="links">
      <span>New member?</span>
      <a href="register.php">Create an account</a>
    </div>

    <?php if ($error): ?>
      <div class="msg"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="test">
      Testing accounts (from SQL seed):<br>
      Admin: <span class="chip">admin</span> / <span class="chip">admin123</span><br>
      Trainer: <span class="chip">trainer_john</span> / <span class="chip">trainer123</span><br>
      Member: <span class="chip">member_ali</span> / <span class="chip">member123</span>
    </div>
  </div>
</body>
</html>
