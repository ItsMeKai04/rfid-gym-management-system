<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

// only admin
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'Admin') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Same defaults as admin_attendance.php
$defaultStart = date('Y-m-d', strtotime('-7 days'));
$defaultEnd   = date('Y-m-d');

$start_date = $_GET['start_date'] ?? $defaultStart;
$end_date   = $_GET['end_date'] ?? $defaultEnd;

// Ensure proper order
if ($start_date > $end_date) {
    $tmp        = $start_date;
    $start_date = $end_date;
    $end_date   = $tmp;
}

/**
 * We detect "new record" by checking the latest datetime in the range.
 * If your tables don't have updated_at, this is the safest.
 * Uses attendance_date + check_in_time.
 */

// Latest MEMBER activity (check-in OR check-out) in range
$stmt = $pdo->prepare("
    SELECT GREATEST(
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_in_time,'00:00:00'))), ''),
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_out_time,'00:00:00'))), '')
    ) AS last_member
    FROM attendance
    WHERE attendance_date BETWEEN :start AND :end
");
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$lastMember = $stmt->fetchColumn();

// Latest TRAINER activity (check-in OR check-out) in range
$stmt = $pdo->prepare("
    SELECT GREATEST(
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_in_time,'00:00:00'))), ''),
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_out_time,'00:00:00'))), '')
    ) AS last_trainer
    FROM trainer_attendance
    WHERE attendance_date BETWEEN :start AND :end
");
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$lastTrainer = $stmt->fetchColumn();


echo json_encode([
    'start_date'   => $start_date,
    'end_date'     => $end_date,
    'last_member'  => $lastMember ?: '',
    'last_trainer' => $lastTrainer ?: '',
]);
