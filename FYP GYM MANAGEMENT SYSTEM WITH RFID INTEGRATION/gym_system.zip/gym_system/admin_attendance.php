<?php
session_start();
require_once 'db.php';

// only admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

$adminName = $_SESSION['full_name'] ?? 'Admin';

// Date filter (default: last 7 days)
$defaultStart = date('Y-m-d', strtotime('-7 days'));
$defaultEnd   = date('Y-m-d');

$start_date = $_GET['start_date'] ?? $defaultStart;
$end_date   = $_GET['end_date'] ?? $defaultEnd;

// Ensure proper order
if ($start_date > $end_date) {
    $tmp        = $start_date;
    $start_date = $end_date;
    $end_date   = $tmp;
}

/* ==== MEMBER ATTENDANCE STATS ==== */
$sqlMemberStats = "
    SELECT
        COUNT(*) AS total,
        SUM(status = 'Present') AS present_count,
        SUM(status = 'Absent') AS absent_count,
        SUM(status = 'Late') AS late_count,
        SUM(status = 'Excused') AS excused_count
    FROM attendance
    WHERE attendance_date BETWEEN :start AND :end
";
$stmt = $pdo->prepare($sqlMemberStats);
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$memberStats = $stmt->fetch() ?: [
    'total'          => 0,
    'present_count'  => 0,
    'absent_count'   => 0,
    'late_count'     => 0,
    'excused_count'  => 0,
];

// Member attendance list (limit 50)
$sqlMemberList = "
    SELECT a.*, 
           m.full_name AS member_name,
           t.full_name AS trainer_name
    FROM attendance a
    JOIN members m ON a.member_id = m.member_id
    LEFT JOIN trainers t ON a.trainer_id = t.trainer_id
    WHERE a.attendance_date BETWEEN :start AND :end
    ORDER BY a.attendance_date DESC, a.check_in_time DESC
    LIMIT 50
";
$stmt = $pdo->prepare($sqlMemberList);
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$memberRecords = $stmt->fetchAll();

/* ==== TRAINER ATTENDANCE STATS ==== */
$sqlTrainerStats = "
    SELECT
        COUNT(*) AS total,
        SUM(status = 'Present') AS present_count,
        SUM(status = 'Absent') AS absent_count,
        SUM(status = 'Late') AS late_count,
        SUM(status = 'Excused') AS excused_count
    FROM trainer_attendance
    WHERE attendance_date BETWEEN :start AND :end
";
$stmt = $pdo->prepare($sqlTrainerStats);
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$trainerStats = $stmt->fetch() ?: [
    'total'          => 0,
    'present_count'  => 0,
    'absent_count'   => 0,
    'late_count'     => 0,
    'excused_count'  => 0,
];

// Trainer attendance list (limit 50)
$sqlTrainerList = "
    SELECT ta.*, 
           tr.full_name AS trainer_name
    FROM trainer_attendance ta
    JOIN trainers tr ON ta.trainer_id = tr.trainer_id
    WHERE ta.attendance_date BETWEEN :start AND :end
    ORDER BY ta.attendance_date DESC, ta.check_in_time DESC
    LIMIT 50
";
$stmt = $pdo->prepare($sqlTrainerList);
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$trainerRecords = $stmt->fetchAll();

/* === INITIAL "LAST ACTIVITY" SNAPSHOT (check-in OR check-out) === */
$stmt = $pdo->prepare("
    SELECT GREATEST(
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_in_time,'00:00:00'))), ''),
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_out_time,'00:00:00'))), '')
    ) AS last_member
    FROM attendance
    WHERE attendance_date BETWEEN :start AND :end
");
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$initialLastMember = $stmt->fetchColumn() ?: '';

$stmt = $pdo->prepare("
    SELECT GREATEST(
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_in_time,'00:00:00'))), ''),
        COALESCE(MAX(CONCAT(attendance_date, ' ', IFNULL(check_out_time,'00:00:00'))), '')
    ) AS last_trainer
    FROM trainer_attendance
    WHERE attendance_date BETWEEN :start AND :end
");
$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$initialLastTrainer = $stmt->fetchColumn() ?: '';

$stmt->execute([':start' => $start_date, ':end' => $end_date]);
$initialLastTrainer = $stmt->fetchColumn() ?: '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin - Attendance Overview</title>

    <style>
        :root{
            --bg:#0b0b0f;
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
            --danger:#b91c1c;
            --success:#16a34a;
            --warn:#d97706;
            --info:#38bdf8;
        }
        *{ box-sizing:border-box; }

        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{ display:flex; align-items:center; gap:10px; }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.05); }

        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{ margin:0; font-size: 20px; }
        .small{ margin: 6px 0 0; color: var(--muted); font-size: 13px; }

        .box{
            margin-top: 14px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }
        .section-title{ margin:0 0 10px; font-size: 16px; }

        .filter-row{
            display:flex;
            flex-wrap:wrap;
            gap: 10px 14px;
            align-items:end;
        }
        label{
            font-size: 12px;
            letter-spacing:.04em;
            color: #cfd3df;
        }
        input[type="date"]{
            padding: 10px 10px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.35);
            color: var(--text);
        }
        input[type="date"]:focus{
            outline:none;
            border-color: rgba(124,140,255,.7);
            box-shadow: 0 0 0 3px rgba(124,140,255,.15);
        }
        .hint{
            color: var(--muted);
            font-size: 12px;
            margin-left: 6px;
        }

        .grid{
            display:grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
            margin-top: 14px;
        }
        .statcard{
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }
        .statcard h3{
            margin:0 0 6px;
            font-size: 12px;
            letter-spacing:.10em;
            text-transform: uppercase;
            color: #b9c0cf;
        }
        .statval{
            font-size: 26px;
            font-weight: 800;
            margin: 0 0 6px;
        }
        .sub{
            font-size: 12px;
            color: var(--muted);
            line-height: 1.6;
        }

        .sections{
            display:grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-top: 14px;
        }
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 12px;
            overflow:hidden;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{ background: rgba(255,255,255,.02); }

        .badge{
            display:inline-flex;
            align-items:center;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 800;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
        }
        .badge-present{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .badge-absent{  border-color: rgba(185,28,28,.35); background: rgba(185,28,28,.12); }
        .badge-late{    border-color: rgba(217,119,6,.35);  background: rgba(217,119,6,.12); }
        .badge-excused{ border-color: rgba(56,189,248,.35); background: rgba(56,189,248,.12); }

        .muted{ color: var(--muted); font-size: 12px; }

        @media (max-width: 980px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .grid{ grid-template-columns: 1fr; }
            .sections{ grid-template-columns: 1fr; }
        }
    </style>

    <!-- ✅ ONLY reload when new attendance is detected -->
    <script>
        const POLL_MS = 3000; // check every 3s (no reload unless changed)

        const startDate = <?= json_encode($start_date) ?>;
        const endDate   = <?= json_encode($end_date) ?>;

        let lastMember  = <?= json_encode($initialLastMember) ?>;
        let lastTrainer = <?= json_encode($initialLastTrainer) ?>;

        let pausePoll = false;

        async function pollAttendance() {
            if (pausePoll) return;

            const url = `admin_attendance_poll.php?start_date=${encodeURIComponent(startDate)}&end_date=${encodeURIComponent(endDate)}`;

            try {
                const res = await fetch(url, { cache: "no-store" });
                if (!res.ok) return;

                const data = await res.json();
                if (!data) return;

                const newMember  = data.last_member || "";
                const newTrainer = data.last_trainer || "";

                if (newMember !== lastMember || newTrainer !== lastTrainer) {
                    window.location.reload();
                }
            } catch (e) {
                // silent fail (no spam). Page still usable.
            }
        }

        window.addEventListener("DOMContentLoaded", () => {
            const s = document.getElementById("start_date");
            const e = document.getElementById("end_date");

            const pause = () => pausePoll = true;
            const resume = () => pausePoll = false;

            if (s) { s.addEventListener("focus", pause); s.addEventListener("blur", resume); s.addEventListener("input", pause); }
            if (e) { e.addEventListener("focus", pause); e.addEventListener("blur", resume); e.addEventListener("input", pause); }

            setInterval(pollAttendance, POLL_MS);
        });
    </script>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Attendance</span>
    </div>
    <div class="navright">
        <a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Attendance Overview</h1>
                <p class="small">Logged in as: <?php echo htmlspecialchars($adminName); ?> (Admin)</p>
            </div>
        </div>

        <div class="box">
            <h2 class="section-title">Filter by Date</h2>
            <form method="GET" action="admin_attendance.php">
                <div class="filter-row">
                    <div>
                        <label for="start_date">From</label><br>
                        <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                    <div>
                        <label for="end_date">To</label><br>
                        <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary">Filter</button>
                    </div>
                    <div class="hint">
                        Showing records from <strong><?php echo htmlspecialchars($start_date); ?></strong>
                        to <strong><?php echo htmlspecialchars($end_date); ?></strong>
                        <span class="hint" style="display:inline-block;margin-left:10px;">• Live updates (reload only on new record)</span>
                    </div>
                </div>
            </form>
        </div>

        <div class="grid">
            <div class="statcard">
                <h3>Member Attendance</h3>
                <div class="statval"><?php echo (int)$memberStats['total']; ?></div>
                <div class="sub">
                    Present: <?php echo (int)$memberStats['present_count']; ?> |
                    Absent: <?php echo (int)$memberStats['absent_count']; ?> |
                    Late: <?php echo (int)$memberStats['late_count']; ?> |
                    Excused: <?php echo (int)$memberStats['excused_count']; ?>
                </div>
            </div>

            <div class="statcard">
                <h3>Trainer Attendance</h3>
                <div class="statval"><?php echo (int)$trainerStats['total']; ?></div>
                <div class="sub">
                    Present: <?php echo (int)$trainerStats['present_count']; ?> |
                    Absent: <?php echo (int)$trainerStats['absent_count']; ?> |
                    Late: <?php echo (int)$trainerStats['late_count']; ?> |
                    Excused: <?php echo (int)$trainerStats['excused_count']; ?>
                </div>
            </div>
        </div>

        <div class="sections">
            <div class="box">
                <h2 class="section-title">Member Attendance (latest 50)</h2>
                <?php if (count($memberRecords) === 0): ?>
                    <p class="muted">No member attendance records for this period.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Member</th>
                            <th>Trainer</th>
                            <th>Check-in</th>
                            <th>Check-out</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($memberRecords as $r): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($r['attendance_date']); ?></td>
                                <td><?php echo htmlspecialchars($r['member_name']); ?></td>
                                <td><?php echo htmlspecialchars($r['trainer_name'] ?? '-'); ?></td>
                                <td><?php echo htmlspecialchars($r['check_in_time']); ?></td>
                                <td><?php echo htmlspecialchars($r['check_out_time']); ?></td>
                                <td>
                                    <?php
                                    $st  = $r['status'];
                                    $cls = 'badge ';
                                    if ($st === 'Present') $cls .= 'badge-present';
                                    elseif ($st === 'Absent') $cls .= 'badge-absent';
                                    elseif ($st === 'Late') $cls .= 'badge-late';
                                    else $cls .= 'badge-excused';
                                    ?>
                                    <span class="<?php echo $cls; ?>"><?php echo htmlspecialchars($st); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="box">
                <h2 class="section-title">Trainer Attendance (latest 50)</h2>
                <?php if (count($trainerRecords) === 0): ?>
                    <p class="muted">No trainer attendance records for this period.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Trainer</th>
                            <th>Check-in</th>
                            <th>Check-out</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($trainerRecords as $r): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($r['attendance_date']); ?></td>
                                <td><?php echo htmlspecialchars($r['trainer_name']); ?></td>
                                <td><?php echo htmlspecialchars($r['check_in_time']); ?></td>
                                <td><?php echo htmlspecialchars($r['check_out_time']); ?></td>
                                <td>
                                    <?php
                                    $st  = $r['status'];
                                    $cls = 'badge ';
                                    if ($st === 'Present') $cls .= 'badge-present';
                                    elseif ($st === 'Absent') $cls .= 'badge-absent';
                                    elseif ($st === 'Late') $cls .= 'badge-late';
                                    else $cls .= 'badge-excused';
                                    ?>
                                    <span class="<?php echo $cls; ?>"><?php echo htmlspecialchars($st); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

</body>
</html>
