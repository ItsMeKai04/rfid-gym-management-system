<?php
session_start();
require_once 'db.php';

// Only admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

$action  = $_GET['action'] ?? 'list';
$message = '';
$error   = '';

$adminName = $_SESSION['full_name'] ?? 'Admin';

// Handle ADD assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
    $member_id  = (int)($_POST['member_id'] ?? 0);
    $trainer_id = (int)($_POST['trainer_id'] ?? 0);

    if ($member_id <= 0 || $trainer_id <= 0) {
        $error = 'Please select both member and trainer.';
    } else {
        try {
            $sql = "INSERT INTO member_trainer_assigned (member_id, trainer_id)
                    VALUES (:member_id, :trainer_id)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':member_id'  => $member_id,
                ':trainer_id' => $trainer_id,
            ]);
            $message = 'Trainer assigned to member successfully.';
        } catch (PDOException $e) {
            // duplicate entry handling
            if ($e->getCode() === '23000') {
                $error = 'This trainer is already assigned to that member.';
            } else {
                $error = 'Error assigning trainer: ' . $e->getMessage();
            }
        }
    }
}

// Handle DELETE assignment
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    try {
        $stmt = $pdo->prepare("DELETE FROM member_trainer_assigned WHERE id = :id");
        $stmt->execute([':id' => $id]);
        if ($stmt->rowCount() > 0) {
            $message = 'Assignment deleted successfully.';
        } else {
            $error = 'Assignment not found.';
        }
    } catch (PDOException $e) {
        $error = 'Error deleting assignment: ' . $e->getMessage();
    }

    $action = 'list';
}

// Fetch all members for dropdown
$members = $pdo->query("
    SELECT m.member_id, m.full_name, u.username
    FROM members m
    JOIN users u ON m.user_id = u.user_id
    ORDER BY m.full_name
")->fetchAll();

// Fetch all trainers for dropdown
$trainers = $pdo->query("
    SELECT t.trainer_id, t.full_name, u.username
    FROM trainers t
    JOIN users u ON t.user_id = u.user_id
    ORDER BY t.full_name
")->fetchAll();

// Fetch existing assignments for list view
$assignments = [];
if ($action === 'list') {
    $sql = "
        SELECT a.id,
               m.member_id,
               m.full_name AS member_name,
               um.username AS member_username,
               t.trainer_id,
               t.full_name AS trainer_name,
               ut.username AS trainer_username,
               a.assigned_at
        FROM member_trainer_assigned a
        JOIN members m   ON a.member_id = m.member_id
        JOIN users  um   ON m.user_id   = um.user_id
        JOIN trainers t  ON a.trainer_id = t.trainer_id
        JOIN users  ut   ON t.user_id    = ut.user_id
        ORDER BY a.assigned_at DESC
    ";
    $stmt = $pdo->query($sql);
    $assignments = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin - Assign Trainer to Members</title>

    <style>
        :root{
            --bg:#0b0b0f;
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
        }

        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* Topnav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;
            border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{
            display:flex;
            align-items:center;
            gap:10px;
        }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.05); }
        .btn-danger{
            background: rgba(185,28,28,.85);
            border-color: rgba(185,28,28,.35);
        }
        .btn-danger:hover{ filter: brightness(1.05); }

        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{
            margin:0;
            font-size: 20px;
        }
        .small{
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 13px;
        }

        .msg{
            border-radius: 12px;
            padding: 10px 12px;
            font-size: 13px;
            margin-top: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.05);
        }
        .msg-success{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .msg-error{ border-color: rgba(185,28,28,.35); background: rgba(185,28,28,.12); }

        .box{
            margin-top: 14px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }

        .section-title{
            margin:0 0 10px;
            font-size: 16px;
        }

        /* Form row */
        form{ margin:0; }
        .form-row{
            display:grid;
            grid-template-columns: 1fr 1fr auto;
            gap: 12px;
            align-items:end;
        }
        label{
            font-size: 12px;
            letter-spacing:.04em;
            color: #cfd3df;
        }
        select{
            width:100%;
            padding: 10px 10px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.35);
            color: var(--text);
        }
        select:focus{
            outline:none;
            border-color: rgba(124,140,255,.7);
            box-shadow: 0 0 0 3px rgba(124,140,255,.15);
        }

        /* Tables */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 12px;
            overflow:hidden;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{
            background: rgba(255,255,255,.02);
        }

        .muted{
            color: var(--muted);
            font-size: 12px;
        }

        @media (max-width: 980px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .form-row{ grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Assign Trainer</span>
    </div>
    <div class="navright">
        <a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Assign Trainer to Members</h1>
                <p class="small">Logged in as: <?php echo htmlspecialchars($adminName); ?> (Admin)</p>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="box" style="margin-top:14px;">
            <h2 class="section-title">Create New Assignment</h2>
            <form method="POST" action="admin_assign_trainer.php?action=add">
                <div class="form-row">
                    <div>
                        <label for="member_id">Member</label><br>
                        <select name="member_id" id="member_id" required>
                            <option value="">-- Select Member --</option>
                            <?php foreach ($members as $m): ?>
                                <option value="<?php echo $m['member_id']; ?>">
                                    <?php echo htmlspecialchars($m['full_name'] . " ({$m['username']})"); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label for="trainer_id">Trainer</label><br>
                        <select name="trainer_id" id="trainer_id" required>
                            <option value="">-- Select Trainer --</option>
                            <?php foreach ($trainers as $t): ?>
                                <option value="<?php echo $t['trainer_id']; ?>">
                                    <?php echo htmlspecialchars($t['full_name'] . " ({$t['username']})"); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <button type="submit" class="btn btn-primary" style="width:100%;">Assign</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="box">
            <h2 class="section-title">Existing Assignments</h2>

            <?php if (count($assignments) === 0): ?>
                <p class="small">No assignments found.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Member</th>
                        <th>Trainer</th>
                        <th>Assigned At</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($assignments as $a): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($a['id']); ?></td>
                            <td>
                                <?php echo htmlspecialchars($a['member_name']); ?>
                                <span class="muted">(<?php echo htmlspecialchars($a['member_username']); ?>)</span>
                            </td>
                            <td>
                                <?php echo htmlspecialchars($a['trainer_name']); ?>
                                <span class="muted">(<?php echo htmlspecialchars($a['trainer_username']); ?>)</span>
                            </td>
                            <td><?php echo htmlspecialchars($a['assigned_at']); ?></td>
                            <td>
                                <a href="admin_assign_trainer.php?action=delete&id=<?php echo $a['id']; ?>"
                                   class="btn btn-danger"
                                   onclick="return confirm('Remove this assignment?');">
                                    Delete
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>

    </div>
</div>

</body>
</html>
