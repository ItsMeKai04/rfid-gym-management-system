<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Trainer') {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM trainers WHERE user_id = :uid LIMIT 1");
$stmt->execute([':uid' => $userId]);
$trainer = $stmt->fetch();
if (!$trainer) die('Trainer not found.');

$trainerId = $trainer['trainer_id'];
$action    = $_GET['action'] ?? 'list';
$message   = '';
$error     = '';

// Members assigned to this trainer
$sqlMembers = "
    SELECT m.member_id, m.full_name
    FROM member_trainer_assigned a
    JOIN members m ON a.member_id = m.member_id
    WHERE a.trainer_id = :tid
    ORDER BY m.full_name
";
$stmt = $pdo->prepare($sqlMembers);
$stmt->execute([':tid'=>$trainerId]);
$members = $stmt->fetchAll();

// Workouts created by this trainer
$sqlWorkouts = "SELECT workout_id, title FROM workouts WHERE trainer_id = :tid ORDER BY title";
$stmt = $pdo->prepare($sqlWorkouts);
$stmt->execute([':tid'=>$trainerId]);
$workouts = $stmt->fetchAll();

// ADD schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
    $workout_id = (int)($_POST['workout_id'] ?? 0);
    $member_id  = (int)($_POST['member_id'] ?? 0);
    $class_date = $_POST['class_date'] ?? null;
    $start_time = $_POST['start_time'] ?? null;
    $end_time   = $_POST['end_time'] ?? null;

    if ($workout_id <= 0 || $member_id <= 0 || !$class_date || !$start_time || !$end_time) {
        $error = 'All fields are required.';
    } else {
        $sql = "INSERT INTO schedules (workout_id, member_id, trainer_id, class_date, start_time, end_time)
                VALUES (:workout_id, :member_id, :trainer_id, :class_date, :start_time, :end_time)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':workout_id' => $workout_id,
            ':member_id'  => $member_id,
            ':trainer_id' => $trainerId,
            ':class_date' => $class_date,
            ':start_time' => $start_time,
            ':end_time'   => $end_time,
        ]);
        $message = 'Schedule created.';
        $action  = 'list';
    }
}

// EDIT schedule
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'edit') {
    $schedule_id = (int)($_POST['schedule_id'] ?? 0);
    $class_date  = $_POST['class_date'] ?? null;
    $start_time  = $_POST['start_time'] ?? null;
    $end_time    = $_POST['end_time'] ?? null;

    if ($schedule_id <= 0 || !$class_date || !$start_time || !$end_time) {
        $error = 'All fields are required.';
    } else {
        $sql = "UPDATE schedules
                SET class_date = :class_date,
                    start_time = :start_time,
                    end_time   = :end_time
                WHERE schedule_id = :sid AND trainer_id = :tid";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':class_date' => $class_date,
            ':start_time' => $start_time,
            ':end_time'   => $end_time,
            ':sid'        => $schedule_id,
            ':tid'        => $trainerId,
        ]);
        if ($stmt->rowCount() > 0) {
            $message = 'Schedule updated.';
        } else {
            $error = 'Schedule not found or no changes.';
        }
        $action = 'list';
    }
}

// DELETE schedule
if ($action === 'delete' && isset($_GET['id'])) {
    $sid = (int)$_GET['id'];
    $sql = "DELETE FROM schedules WHERE schedule_id = :sid AND trainer_id = :tid";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':sid'=>$sid, ':tid'=>$trainerId]);
    if ($stmt->rowCount() > 0) {
        $message = 'Schedule deleted.';
    } else {
        $error = 'Schedule not found.';
    }
    $action = 'list';
}

// FETCH schedules (upcoming)
$schedules = [];
if ($action === 'list') {
    $today = date('Y-m-d');
    $sql = "
        SELECT s.*, m.full_name AS member_name, w.title AS workout_title
        FROM schedules s
        LEFT JOIN members m ON s.member_id = m.member_id
        LEFT JOIN workouts w ON s.workout_id = w.workout_id
        WHERE s.trainer_id = :tid
          AND s.class_date >= :today
        ORDER BY s.class_date, s.start_time
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':tid'=>$trainerId, ':today'=>$today]);
    $schedules = $stmt->fetchAll();
}

// Single schedule for edit
$editSchedule = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $sid = (int)$_GET['id'];
    $sql = "
        SELECT s.*, m.full_name AS member_name, w.title AS workout_title
        FROM schedules s
        LEFT JOIN members m ON s.member_id = m.member_id
        LEFT JOIN workouts w ON s.workout_id = w.workout_id
        WHERE s.schedule_id = :sid AND s.trainer_id = :tid
        LIMIT 1
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':sid'=>$sid, ':tid'=>$trainerId]);
    $editSchedule = $stmt->fetch();
    if (!$editSchedule) {
        $error  = 'Schedule not found.';
        $action = 'list';
    }
}

function formatTimeRange($start, $end){
    if (!$start || !$end) return '-';
    return htmlspecialchars($start . ' - ' . $end);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Trainer - Schedule Management</title>
    <style>
        :root{
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
            --danger:#b91c1c;
        }
        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* top sticky nav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; }

        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.06); }
        .btn-danger{
            background: rgba(185,28,28,.9);
            border-color: rgba(255,255,255,.10);
        }
        .btn-danger:hover{ filter: brightness(1.05); }

        .container{
            width: min(1100px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{ margin:0; font-size: 20px; }
        .small{ margin: 6px 0 0; color: var(--muted); font-size: 13px; }

        /* messages */
        .msg{
            margin-top: 12px;
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.04);
            font-size: 13px;
        }
        .msg-success{ border-color: rgba(22,163,74,.25); background: rgba(22,163,74,.10); }
        .msg-error{ border-color: rgba(185,28,28,.25); background: rgba(185,28,28,.10); }

        /* forms */
        .section-title{ margin: 16px 0 6px; font-size: 16px; }
        .hint{ margin: 0 0 10px; color: var(--muted); font-size: 12px; }
        .form-grid{
            margin-top: 12px;
            display:grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 12px 14px;
        }
        .form-group{ display:flex; flex-direction:column; gap:6px; }
        label{ font-size: 12px; color: var(--muted); letter-spacing: .03em; }
        input, select{
            padding: 10px 12px;
            border-radius: 14px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.25);
            color: var(--text);
        }
        input:focus, select:focus{
            outline:none;
            border-color: rgba(124,140,255,.55);
            box-shadow: 0 0 0 3px rgba(124,140,255,.12);
        }
        .form-actions{
            margin-top: 14px;
            display:flex;
            gap:10px;
            flex-wrap:wrap;
        }

        /* table */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 14px;
            overflow:hidden;
            margin-top: 12px;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{ background: rgba(255,255,255,.02); }
        .actions{ display:flex; gap:8px; flex-wrap:wrap; }

        @media (max-width: 900px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .form-grid{ grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Trainer</span>
    </div>

    <div class="navright">
        <a href="trainer_dashboard.php" class="btn">← Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Schedule Management</h1>
                <p class="small">Manage your upcoming training sessions.</p>
            </div>
        </div>

        <?php if ($message): ?><div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
        <?php if ($error): ?><div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

        <?php if ($action === 'list'): ?>

            <h2 class="section-title">Add New Session</h2>

            <?php if (count($members) === 0 || count($workouts) === 0): ?>
                <p class="hint">You need at least one assigned member and one workout plan to create a schedule.</p>
            <?php else: ?>
                <form method="POST" action="trainer_schedule.php?action=add">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="member_id">Member *</label>
                            <select name="member_id" id="member_id" required>
                                <option value="">-- Select Member --</option>
                                <?php foreach ($members as $m): ?>
                                    <option value="<?php echo $m['member_id']; ?>">
                                        <?php echo htmlspecialchars($m['full_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="workout_id">Workout Plan *</label>
                            <select name="workout_id" id="workout_id" required>
                                <option value="">-- Select Workout --</option>
                                <?php foreach ($workouts as $w): ?>
                                    <option value="<?php echo $w['workout_id']; ?>">
                                        <?php echo htmlspecialchars($w['title']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="class_date">Date *</label>
                            <input type="date" id="class_date" name="class_date" required>
                        </div>

                        <div class="form-group">
                            <label for="start_time">Start Time *</label>
                            <input type="time" id="start_time" name="start_time" required>
                        </div>

                        <div class="form-group">
                            <label for="end_time">End Time *</label>
                            <input type="time" id="end_time" name="end_time" required>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Save Session</button>
                    </div>
                </form>
            <?php endif; ?>

            <h2 class="section-title" style="margin-top:18px;">Upcoming Sessions</h2>

            <?php if (count($schedules) === 0): ?>
                <p class="hint">No sessions scheduled.</p>
            <?php else: ?>
                <table>
                    <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Member</th>
                        <th>Workout</th>
                        <th style="width:220px;">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($schedules as $s): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($s['class_date']); ?></td>
                            <td><?php echo formatTimeRange($s['start_time'], $s['end_time']); ?></td>
                            <td><?php echo htmlspecialchars($s['member_name'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($s['workout_title'] ?? '-'); ?></td>
                            <td>
                                <div class="actions">
                                    <a href="trainer_schedule.php?action=edit&id=<?php echo $s['schedule_id']; ?>" class="btn">Edit</a>
                                    <a href="trainer_schedule.php?action=delete&id=<?php echo $s['schedule_id']; ?>" class="btn btn-danger"
                                       onclick="return confirm('Delete this session?');">Delete</a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

        <?php elseif ($action === 'edit' && $editSchedule): ?>

            <h2 class="section-title">Edit Session</h2>
            <p class="hint">
                Member: <b><?php echo htmlspecialchars($editSchedule['member_name'] ?? '-'); ?></b> ·
                Workout: <b><?php echo htmlspecialchars($editSchedule['workout_title'] ?? '-'); ?></b>
            </p>

            <form method="POST" action="trainer_schedule.php?action=edit">
                <input type="hidden" name="schedule_id" value="<?php echo htmlspecialchars($editSchedule['schedule_id']); ?>">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="class_date">Date *</label>
                        <input type="date" id="class_date" name="class_date" required
                               value="<?php echo htmlspecialchars($editSchedule['class_date']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="start_time">Start Time *</label>
                        <input type="time" id="start_time" name="start_time" required
                               value="<?php echo htmlspecialchars($editSchedule['start_time']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="end_time">End Time *</label>
                        <input type="time" id="end_time" name="end_time" required
                               value="<?php echo htmlspecialchars($editSchedule['end_time']); ?>">
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Session</button>
                    <a href="trainer_schedule.php" class="btn">Cancel</a>
                </div>
            </form>

        <?php endif; ?>

    </div>
</div>

</body>
</html>
