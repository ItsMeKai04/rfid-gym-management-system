<?php
require_once 'db.php';
date_default_timezone_set('Asia/Kuala_Lumpur');
header('Content-Type: application/json');

$API_KEY = "MY_SECRET_KEY";

$uid = strtoupper(trim($_GET['uid'] ?? ''));
$key = trim($_GET['key'] ?? '');

if ($key !== $API_KEY) {
    http_response_code(401);
    echo json_encode(["status"=>"error","message"=>"Invalid API key"]);
    exit;
}
if ($uid === '') {
    http_response_code(400);
    echo json_encode(["status"=>"error","message"=>"UID missing"]);
    exit;
}

// 1) find trainer by uid
$stmt = $pdo->prepare("
    SELECT trainer_id
    FROM rfid_trainer_tags
    WHERE tag_uid = :uid AND status = 'Active'
    LIMIT 1
");
$stmt->execute([':uid' => $uid]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row) {
    http_response_code(404);
    echo json_encode(["status"=>"error","message"=>"Trainer card not registered"]);
    exit;
}

$trainerId = (int)$row['trainer_id'];
$today = date('Y-m-d');

// 2) check today record
$stmt = $pdo->prepare("
    SELECT id, check_in_time, check_out_time
    FROM trainer_attendance
    WHERE trainer_id = :tid AND attendance_date = :d
    ORDER BY id DESC
    LIMIT 1
");
$stmt->execute([':tid'=>$trainerId, ':d'=>$today]);
$att = $stmt->fetch(PDO::FETCH_ASSOC);

// NOTE: kalau table kau bukan id/attendance_date, bagitau aku column names.
// Aku set default common names.

if (!$att) {
    // check-in
    $stmt = $pdo->prepare("
        INSERT INTO trainer_attendance (trainer_id, check_in_time, attendance_date, remarks)
        VALUES (:tid, NOW(), :d, 'RFID trainer check-in')
    ");
    $stmt->execute([':tid'=>$trainerId, ':d'=>$today]);

    echo json_encode(["status"=>"ok","action"=>"check_in","trainer_id"=>$trainerId]);
    exit;
}

if (empty($att['check_out_time'])) {
    // check-out
    $stmt = $pdo->prepare("
        UPDATE trainer_attendance
        SET check_out_time = NOW(), remarks = 'RFID trainer check-out'
        WHERE id = :id
    ");
    $stmt->execute([':id'=>$att['id']]);

    echo json_encode(["status"=>"ok","action"=>"check_out","trainer_id"=>$trainerId]);
    exit;
}

// already checked out -> optional new check-in
$stmt = $pdo->prepare("
    INSERT INTO trainer_attendance (trainer_id, check_in_time, attendance_date, remarks)
    VALUES (:tid, NOW(), :d, 'RFID trainer re-check-in')
");
$stmt->execute([':tid'=>$trainerId, ':d'=>$today]);

echo json_encode(["status"=>"ok","action"=>"check_in_again","trainer_id"=>$trainerId]);
