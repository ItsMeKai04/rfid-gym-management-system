<?php
session_start();
require_once 'db.php';

// Only admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header('Location: login.php');
    exit;
}

$action  = $_GET['action'] ?? 'list';
$message = '';
$error   = '';

$adminName = $_SESSION['full_name'] ?? 'Admin';

// Helper: get member data (join users + members)
function getMemberById(PDO $pdo, $member_id) {
    $sql = "SELECT m.*, u.username, u.email AS user_email, u.full_name AS user_full_name, u.user_id
            FROM members m
            JOIN users u ON m.user_id = u.user_id
            WHERE m.member_id = :member_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':member_id' => $member_id]);
    return $stmt->fetch();
}

/**
 * HANDLE FORM SUBMISSIONS
 */

// ADD MEMBER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'add') {
    $username           = trim($_POST['username'] ?? '');
    $password           = $_POST['password'] ?? '';
    $full_name          = trim($_POST['full_name'] ?? '');
    $email              = trim($_POST['email'] ?? '');
    $phone_number       = trim($_POST['phone_number'] ?? '');
    $date_of_birth      = $_POST['date_of_birth'] ?: null;
    $membership_status  = $_POST['membership_status'] ?? 'Active';
    $join_date          = $_POST['join_date'] ?: null;
    $expiry_date        = $_POST['expiry_date'] ?: null;

    if ($username === '' || $password === '' || $full_name === '') {
        $error = 'Username, password and full name are required.';
    } else {
        try {
            $pdo->beginTransaction();

            // 1) Insert into users table (role = Member)
            $sqlUser = "INSERT INTO users (username, password_hash, full_name, email, role, status)
                        VALUES (:username, SHA2(:password, 256), :full_name, :email, 'Member', 'Active')";
            $stmtUser = $pdo->prepare($sqlUser);
            $stmtUser->execute([
                ':username'  => $username,
                ':password'  => $password,
                ':full_name' => $full_name,
                ':email'     => $email,
            ]);
            $user_id = $pdo->lastInsertId();

            // 2) Insert into members table
            $sqlMember = "INSERT INTO members 
                (user_id, full_name, date_of_birth, email, phone_number, membership_status, join_date, expiry_date)
                VALUES 
                (:user_id, :full_name, :date_of_birth, :email, :phone_number, :membership_status, :join_date, :expiry_date)";
            $stmtMember = $pdo->prepare($sqlMember);
            $stmtMember->execute([
                ':user_id'           => $user_id,
                ':full_name'         => $full_name,
                ':date_of_birth'     => $date_of_birth,
                ':email'             => $email,
                ':phone_number'      => $phone_number,
                ':membership_status' => $membership_status,
                ':join_date'         => $join_date,
                ':expiry_date'       => $expiry_date,
            ]);

            $pdo->commit();
            $message = 'Member created successfully.';
            $action  = 'list'; // go back to list
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Error creating member: ' . $e->getMessage();
        }
    }
}

// EDIT MEMBER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'edit') {
    $member_id          = $_POST['member_id'] ?? null;
    $username           = trim($_POST['username'] ?? '');
    $full_name          = trim($_POST['full_name'] ?? '');
    $email              = trim($_POST['email'] ?? '');
    $phone_number       = trim($_POST['phone_number'] ?? '');
    $date_of_birth      = $_POST['date_of_birth'] ?: null;
    $membership_status  = $_POST['membership_status'] ?? 'Active';
    $join_date          = $_POST['join_date'] ?: null;
    $expiry_date        = $_POST['expiry_date'] ?: null;

    if (!$member_id || $username === '' || $full_name === '') {
        $error = 'Member ID, username and full name are required.';
    } else {
        // Get existing member inc user_id
        $member = getMemberById($pdo, $member_id);
        if (!$member) {
            $error = 'Member not found.';
        } else {
            try {
                $pdo->beginTransaction();

                // 1) Update users table
                $sqlUser = "UPDATE users 
                            SET username = :username, full_name = :full_name, email = :email
                            WHERE user_id = :user_id";
                $stmtUser = $pdo->prepare($sqlUser);
                $stmtUser->execute([
                    ':username'  => $username,
                    ':full_name' => $full_name,
                    ':email'     => $email,
                    ':user_id'   => $member['user_id'],
                ]);

                // 2) Update members table
                $sqlMember = "UPDATE members
                              SET full_name = :full_name,
                                  date_of_birth = :date_of_birth,
                                  email = :email,
                                  phone_number = :phone_number,
                                  membership_status = :membership_status,
                                  join_date = :join_date,
                                  expiry_date = :expiry_date
                              WHERE member_id = :member_id";
                $stmtMember = $pdo->prepare($sqlMember);
                $stmtMember->execute([
                    ':full_name'         => $full_name,
                    ':date_of_birth'     => $date_of_birth,
                    ':email'             => $email,
                    ':phone_number'      => $phone_number,
                    ':membership_status' => $membership_status,
                    ':join_date'         => $join_date,
                    ':expiry_date'       => $expiry_date,
                    ':member_id'         => $member_id,
                ]);

                $pdo->commit();
                $message = 'Member updated successfully.';
                $action  = 'list';
            } catch (PDOException $e) {
                $pdo->rollBack();
                $error = 'Error updating member: ' . $e->getMessage();
            }
        }
    }
}

// DELETE MEMBER
if ($action === 'delete' && isset($_GET['id'])) {
    $member_id = (int) $_GET['id'];

    // Get member to know user_id
    $member = getMemberById($pdo, $member_id);
    if ($member) {
        try {
            $pdo->beginTransaction();

            // Delete user, cascade will remove member row
            $sqlDeleteUser = "DELETE FROM users WHERE user_id = :user_id";
            $stmtDelete = $pdo->prepare($sqlDeleteUser);
            $stmtDelete->execute([':user_id' => $member['user_id']]);

            $pdo->commit();
            $message = 'Member deleted successfully.';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = 'Error deleting member: ' . $e->getMessage();
        }
    } else {
        $error = 'Member not found.';
    }

    $action = 'list';
}

/**
 * FETCH DATA FOR VIEWS
 */
$members = [];

if ($action === 'list') {
    $sql = "SELECT m.member_id, m.full_name, u.username, u.email, 
                   m.membership_status, m.join_date, m.expiry_date
            FROM members m
            JOIN users u ON m.user_id = u.user_id
            ORDER BY m.member_id DESC";
    $stmt = $pdo->query($sql);
    $members = $stmt->fetchAll();
}

$editMember = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $editMember = getMemberById($pdo, (int) $_GET['id']);
    if (!$editMember) {
        $error  = 'Member not found.';
        $action = 'list';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Admin - Member Management</title>

    <style>
        :root{
            --bg:#0b0b0f;
            --text:#e5e7eb;
            --muted:#9ca3af;
            --line:rgba(255,255,255,.08);
            --card:rgba(255,255,255,.04);
            --accent:#5b5ce6;
            --accent2:#7c8cff;
        }

        *{ box-sizing:border-box; }
        body{
            margin:0;
            font-family: Arial, sans-serif;
            color:var(--text);
            background:
                radial-gradient(1200px 600px at 20% 0%, rgba(91,92,230,.18), transparent 55%),
                radial-gradient(900px 500px at 85% 10%, rgba(124,140,255,.14), transparent 60%),
                linear-gradient(#07070a, #0b0b0f 30%, #07070a);
            min-height:100vh;
        }

        /* Topnav */
        .topnav{
            position: sticky;
            top: 0;
            z-index: 50;
            height: 64px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding: 0 28px;
            background: rgba(0,0,0,.55);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255,255,255,.06);
        }
        .brand{
            display:flex;
            align-items:center;
            gap:10px;
            color: var(--accent2);
            font-size: 13px;
            letter-spacing:.02em;
            user-select:none;
        }
        .brand .dot{
            width:10px;height:10px;
            border-radius:999px;
            background: rgba(124,140,255,.9);
            box-shadow: 0 0 0 4px rgba(124,140,255,.15);
        }
        .navright{
            display:flex;
            align-items:center;
            gap:10px;
        }
        .btn{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            cursor:pointer;
            text-decoration:none;
            border:none;
            border-radius: 999px;
            padding: 9px 14px;
            color:#fff;
            background: rgba(255,255,255,.06);
            border: 1px solid rgba(255,255,255,.12);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }
        .btn:hover{ background: rgba(255,255,255,.10); }
        .btn-primary{
            background: rgba(91,92,230,.9);
            border-color: rgba(124,140,255,.25);
        }
        .btn-primary:hover{ filter: brightness(1.05); }
        .btn-danger{
            background: rgba(185,28,28,.85);
            border-color: rgba(185,28,28,.35);
        }
        .btn-danger:hover{ filter: brightness(1.05); }

        /* Main container */
        .container{
            width: min(1200px, calc(100% - 40px));
            margin: 22px auto 60px;
        }

        .panel{
            border-radius: 18px;
            overflow:hidden;
            border:1px solid rgba(255,255,255,.07);
            background:
                linear-gradient(180deg, rgba(0,0,0,.65), rgba(0,0,0,.35)),
                radial-gradient(800px 280px at 15% 10%, rgba(91,92,230,.25), transparent 60%),
                radial-gradient(700px 260px at 85% 0%, rgba(124,140,255,.18), transparent 60%),
                linear-gradient(90deg, rgba(20,20,26,.85), rgba(20,20,26,.55));
            padding: 18px;
        }

        .header-row{
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
        }
        h1{
            margin:0;
            font-size: 20px;
        }
        .small{
            margin: 6px 0 0;
            color: var(--muted);
            font-size: 13px;
        }

        /* messages */
        .msg{
            border-radius: 12px;
            padding: 10px 12px;
            font-size: 13px;
            margin-top: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(255,255,255,.05);
        }
        .msg-success{ border-color: rgba(22,163,74,.35); background: rgba(22,163,74,.12); }
        .msg-error{ border-color: rgba(185,28,28,.35); background: rgba(185,28,28,.12); }

        /* content box */
        .box{
            margin-top: 14px;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 18px;
            padding: 16px;
        }

        /* tables */
        table{
            width:100%;
            border-collapse: collapse;
            font-size: 13px;
            border-radius: 12px;
            overflow:hidden;
        }
        th, td{
            padding: 10px 10px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            text-align:left;
            vertical-align: top;
        }
        th{
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing:.12em;
            color: #b9c0cf;
            background: rgba(255,255,255,.03);
        }
        tr:hover td{
            background: rgba(255,255,255,.02);
        }

        /* badges */
        .badge{
            display:inline-block;
            padding: 3px 10px;
            border-radius: 999px;
            font-size: 11px;
            border: 1px solid rgba(255,255,255,.12);
            background: rgba(255,255,255,.06);
        }
        .badge-active{ background: rgba(22,163,74,.18); border-color: rgba(22,163,74,.35); }
        .badge-expired{ background: rgba(185,28,28,.20); border-color: rgba(185,28,28,.35); }
        .badge-pending{ background: rgba(217,119,6,.18); border-color: rgba(217,119,6,.35); }

        /* forms */
        form{ margin-top: 10px; }
        .form-grid{
            display:grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 12px 16px;
        }
        .form-group{
            display:flex;
            flex-direction: column;
            gap:6px;
        }
        label{
            font-size: 12px;
            letter-spacing:.04em;
            color: #cfd3df;
        }
        input, select{
            padding: 10px 10px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,.10);
            background: rgba(0,0,0,.35);
            color: var(--text);
        }
        input:focus, select:focus{
            outline:none;
            border-color: rgba(124,140,255,.7);
            box-shadow: 0 0 0 3px rgba(124,140,255,.15);
        }
        .actions{
            margin-top: 14px;
            display:flex;
            gap:10px;
            flex-wrap:wrap;
        }

        @media (max-width: 980px){
            .container{ width: calc(100% - 24px); }
            .topnav{ padding: 0 14px; }
            .form-grid{ grid-template-columns: 1fr; }
            table{ font-size: 12px; }
        }
    </style>
</head>
<body>

<div class="topnav">
    <div class="brand">
        <span class="dot"></span>
        <span>GymBroz • Member Management</span>
    </div>
    <div class="navright">
        <a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
        <a href="logout.php" class="btn">Logout</a>
    </div>
</div>

<div class="container">
    <div class="panel">
        <div class="header-row">
            <div>
                <h1>Member Management</h1>
                <p class="small">Logged in as: <?php echo htmlspecialchars($adminName); ?> (Admin)</p>
            </div>

            <?php if ($action === 'list'): ?>
                <div>
                    <a href="admin_members.php?action=add" class="btn btn-primary">+ Add New Member</a>
                </div>
            <?php endif; ?>
        </div>

        <?php if ($message): ?>
            <div class="msg msg-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="msg msg-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <div class="box">

            <?php if ($action === 'list'): ?>

                <?php if (count($members) === 0): ?>
                    <p class="small">No members found.</p>
                <?php else: ?>
                    <table>
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Join Date</th>
                            <th>Expiry Date</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($members as $m): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($m['member_id']); ?></td>
                                <td><?php echo htmlspecialchars($m['username']); ?></td>
                                <td><?php echo htmlspecialchars($m['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($m['email']); ?></td>
                                <td>
                                    <?php
                                    $status = $m['membership_status'];
                                    $class  = 'badge ';
                                    if ($status === 'Active') $class .= 'badge-active';
                                    elseif ($status === 'Expired') $class .= 'badge-expired';
                                    else $class .= 'badge-pending';
                                    ?>
                                    <span class="<?php echo $class; ?>"><?php echo htmlspecialchars($status); ?></span>
                                </td>
                                <td><?php echo htmlspecialchars($m['join_date']); ?></td>
                                <td><?php echo htmlspecialchars($m['expiry_date']); ?></td>
                                <td style="display:flex; gap:8px; flex-wrap:wrap;">
                                    <a class="btn" href="admin_members.php?action=edit&id=<?php echo $m['member_id']; ?>">Edit</a>
                                    <a class="btn btn-danger"
                                       href="admin_members.php?action=delete&id=<?php echo $m['member_id']; ?>"
                                       onclick="return confirm('Are you sure you want to delete this member?');">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>

            <?php elseif ($action === 'add'): ?>

                <h2 style="margin:0 0 8px;">Add New Member</h2>
                <p class="small"><a href="admin_members.php" style="color: var(--accent2); text-decoration:none;">← Back to list</a></p>

                <form method="POST" action="admin_members.php?action=add">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="username">Username *</label>
                            <input type="text" id="username" name="username" required>
                        </div>

                        <div class="form-group">
                            <label for="password">Password *</label>
                            <input type="password" id="password" name="password" required>
                        </div>

                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" id="full_name" name="full_name" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email">
                        </div>

                        <div class="form-group">
                            <label for="phone_number">Phone Number</label>
                            <input type="text" id="phone_number" name="phone_number">
                        </div>

                        <div class="form-group">
                            <label for="date_of_birth">Date of Birth</label>
                            <input type="date" id="date_of_birth" name="date_of_birth">
                        </div>

                        <div class="form-group">
                            <label for="membership_status">Membership Status</label>
                            <select id="membership_status" name="membership_status">
                                <option value="Active">Active</option>
                                <option value="Expired">Expired</option>
                                <option value="Pending">Pending</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="join_date">Join Date</label>
                            <input type="date" id="join_date" name="join_date">
                        </div>

                        <div class="form-group">
                            <label for="expiry_date">Expiry Date</label>
                            <input type="date" id="expiry_date" name="expiry_date">
                        </div>
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn btn-primary">Save Member</button>
                        <a href="admin_members.php" class="btn">Cancel</a>
                    </div>
                </form>

            <?php elseif ($action === 'edit' && $editMember): ?>

                <h2 style="margin:0 0 8px;">Edit Member</h2>
                <p class="small"><a href="admin_members.php" style="color: var(--accent2); text-decoration:none;">← Back to list</a></p>

                <form method="POST" action="admin_members.php?action=edit">
                    <input type="hidden" name="member_id" value="<?php echo htmlspecialchars($editMember['member_id']); ?>">

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="username">Username *</label>
                            <input type="text" id="username" name="username" required
                                   value="<?php echo htmlspecialchars($editMember['username']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" id="full_name" name="full_name" required
                                   value="<?php echo htmlspecialchars($editMember['full_name']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email"
                                   value="<?php echo htmlspecialchars($editMember['email']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="phone_number">Phone Number</label>
                            <input type="text" id="phone_number" name="phone_number"
                                   value="<?php echo htmlspecialchars($editMember['phone_number']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="date_of_birth">Date of Birth</label>
                            <input type="date" id="date_of_birth" name="date_of_birth"
                                   value="<?php echo htmlspecialchars($editMember['date_of_birth']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="membership_status">Membership Status</label>
                            <select id="membership_status" name="membership_status">
                                <option value="Active"  <?php echo $editMember['membership_status'] === 'Active' ? 'selected' : ''; ?>>Active</option>
                                <option value="Expired" <?php echo $editMember['membership_status'] === 'Expired' ? 'selected' : ''; ?>>Expired</option>
                                <option value="Pending" <?php echo $editMember['membership_status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="join_date">Join Date</label>
                            <input type="date" id="join_date" name="join_date"
                                   value="<?php echo htmlspecialchars($editMember['join_date']); ?>">
                        </div>

                        <div class="form-group">
                            <label for="expiry_date">Expiry Date</label>
                            <input type="date" id="expiry_date" name="expiry_date"
                                   value="<?php echo htmlspecialchars($editMember['expiry_date']); ?>">
                        </div>
                    </div>

                    <div class="actions">
                        <button type="submit" class="btn btn-primary">Update Member</button>
                        <a href="admin_members.php" class="btn">Cancel</a>
                    </div>
                </form>

            <?php endif; ?>

        </div>
    </div>
</div>

</body>
</html>
